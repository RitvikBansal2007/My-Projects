from greendash.generator.run import main


if __name__ == "__main__":
    main()
