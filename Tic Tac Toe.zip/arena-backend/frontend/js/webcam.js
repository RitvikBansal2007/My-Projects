/**
 * webcam.js
 * Handles getUserMedia, canvas capture, hardware shutdown,
 * and POSTing to /api/auth/face-login
 */

document.addEventListener('DOMContentLoaded', () => {
  const usernameInput  = document.getElementById('input-username');
  const loginError     = document.getElementById('login-error');
  const errorMsg       = document.getElementById('login-error-msg');

  const videoEl        = document.getElementById('cam-video');
  const canvasEl       = document.getElementById('cam-canvas');
  const ctx            = canvasEl.getContext('2d');

  const camPlaceholder = document.getElementById('cam-placeholder');
  const scanOverlay    = document.getElementById('cam-scan-overlay');
  const camStatus      = document.getElementById('cam-status');
  const verifyOverlay  = document.getElementById('verify-overlay');

  const btnStartCam    = document.getElementById('btn-start-cam');
  const btnCapture     = document.getElementById('btn-capture');
  const btnCaptureLabel= document.getElementById('btn-capture-label');
  const captureSpinner = document.getElementById('capture-spinner');

  let localStream = null;

  // --- Request Camera Permission ---
  btnStartCam.addEventListener('click', async () => {
    try {
      loginError.classList.remove('visible');

      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      localStream = stream;
      videoEl.srcObject = stream;
      await videoEl.play();

      camPlaceholder.classList.add('hidden');
      scanOverlay.classList.add('active');
      camStatus.textContent = 'LIVE';
      camStatus.className   = 'cam-status cam-status--live';

      btnStartCam.style.display = 'none';
      btnCapture.classList.add('visible');

    } catch (err) {
      console.error('Camera access denied:', err);
      showError('Camera access is required to proceed.');
      camStatus.textContent = 'ERROR';
      camStatus.className   = 'cam-status cam-status--error';
    }
  });

  // --- Capture, Stop Hardware, & Verify ---
  btnCapture.addEventListener('click', async () => {
    const username = usernameInput.value.trim();
    if (!username) {
      showError('Please enter a callsign (username).');
      return;
    }

    ctx.drawImage(videoEl, 0, 0, canvasEl.width, canvasEl.height);
    videoEl.style.display   = 'none';
    canvasEl.style.display  = 'block';

    stopCamera();
    setLoadingState(true);

    const base64Image = canvasEl.toDataURL('image/jpeg', 0.85);
    const payload     = base64Image.split(',')[1];

    try {
      const res = await fetch('/api/auth/face-login', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ image: payload, username }),
      });

      if (res.ok) {
        const data = await res.json();

        sessionStorage.setItem('jwt',      data.token);
        sessionStorage.setItem('uid',      data.uid);       
        sessionStorage.setItem('username', data.username);  

        window.location.href = 'lobby.html';

      } else {
        const errData = await res.json();
        showError(errData.detail || 'Verification failed. Face mismatch.');

        setLoadingState(false);
        videoEl.style.display   = 'block';
        canvasEl.style.display  = 'none';
        btnStartCam.style.display = 'inline-flex';
        btnCapture.classList.remove('visible');
        camPlaceholder.classList.remove('hidden');
        scanOverlay.classList.remove('active');
      }

    } catch (err) {
      console.error('Network error:', err);
      showError('Network error. Unable to reach server.');
      setLoadingState(false);
      videoEl.style.display  = 'block';
      canvasEl.style.display = 'none';
    }
  });

  // --- Helpers ---
  function showError(message) {
    errorMsg.textContent = message;
    loginError.classList.add('visible');
  }

  function setLoadingState(isLoading) {
    if (isLoading) {
      verifyOverlay.classList.add('active');
      btnCapture.disabled             = true;
      btnCaptureLabel.style.display   = 'none';
      captureSpinner.style.display    = 'inline-block';
      camStatus.textContent = 'VERIFYING...';
      camStatus.className   = 'cam-status cam-status--verify';
    } else {
      verifyOverlay.classList.remove('active');
      btnCapture.disabled             = false;
      btnCaptureLabel.style.display   = 'inline-block';
      captureSpinner.style.display    = 'none';
      camStatus.textContent = 'LIVE';
      camStatus.className   = 'cam-status cam-status--live';
    }
  }

  function stopCamera() {
    if (localStream) {
      localStream.getTracks().forEach(t => t.stop());
      localStream = null;
    }
  }
});
