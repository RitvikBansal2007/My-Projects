/**
 * matchmaking.js
 * Challenge state machine + modal controller.
 *
 * Message types now match the backend protocol exactly:
 *   Send:    CHALLENGE / ACCEPT_CHALLENGE / DECLINE_CHALLENGE / CANCEL_CHALLENGE
 *   Receive: CHALLENGE_RECEIVED / CHALLENGE_DECLINED / CHALLENGE_CANCELLED /
 *            GAME_START / ERROR
 */
document.addEventListener('DOMContentLoaded', () => {
  const modalReceived = document.getElementById('modal-received');
  const modalPending  = document.getElementById('modal-pending');
  const modalFound    = document.getElementById('modal-match-found');
  const countdownText = document.getElementById('countdown-number');
  const countdownRing = document.getElementById('countdown-ring');

  let challengeTimer    = null;
  let currentOpponentUid  = null;  
  let currentOpponentName = null;   

  // ── Incoming WebSocket events ──────────────────────────────────────────────
  window.arenaWS.addListener((data) => {
    switch (data.type) {
      case 'CHALLENGE_RECEIVED':
        currentOpponentUid  = data.from;
        currentOpponentName = data.from_name || data.from;
        _showIncomingChallenge(currentOpponentName);
        break;

      case 'CHALLENGE_DECLINED':
        modalPending?.classList.remove('visible');
        _showDeclined(data.reason || 'Challenge declined.');
        break;

      case 'CHALLENGE_CANCELLED':
        clearInterval(challengeTimer);
        modalReceived?.classList.remove('visible');
        break;

      case 'GAME_START': {
        clearInterval(challengeTimer);
        modalPending?.classList.remove('visible');
        modalReceived?.classList.remove('visible');
        modalFound?.classList.add('visible');

        const { room_id, symbol, opponent_name, opponent } = data;
        sessionStorage.setItem('room_id',       room_id);
        sessionStorage.setItem('my_symbol',     symbol);
        sessionStorage.setItem('opponent_name', opponent_name || opponent || '');

        setTimeout(() => {
          const oppEnc = encodeURIComponent(opponent_name || opponent || '');
          window.location.href =
            `game.html?room_id=${room_id}&symbol=${encodeURIComponent(symbol)}&opponent=${oppEnc}`;
        }, 1500);
        break;
      }

      case 'ERROR':
        modalPending?.classList.remove('visible');
        _showDeclined(data.reason || 'An error occurred.');
        break;
    }
  });

  // ── Outbound: initiate challenge (called from lobby.js cards) ──────────────
  window.initiateChallenge = (targetUid, targetName) => {
    if (targetUid === sessionStorage.getItem('uid')) return;

    currentOpponentUid  = targetUid;
    currentOpponentName = targetName || targetUid;

    const pendingName = document.getElementById('pending-opponent-name');
    if (pendingName) pendingName.textContent = currentOpponentName;
    modalPending?.classList.add('visible');
    window.arenaWS.send('CHALLENGE', { target_uid: targetUid });
  };

  // ── Button: Accept ─────────────────────────────────────────────────────────
  document.getElementById('btn-accept')?.addEventListener('click', () => {
    clearInterval(challengeTimer);
    window.arenaWS.send('ACCEPT_CHALLENGE', { challenger_uid: currentOpponentUid });
    modalReceived?.classList.remove('visible');
  });

  // ── Button: Decline ────────────────────────────────────────────────────────
  document.getElementById('btn-decline')?.addEventListener('click', () => {
    clearInterval(challengeTimer);
    window.arenaWS.send('DECLINE_CHALLENGE', { challenger_uid: currentOpponentUid });
    modalReceived?.classList.remove('visible');
  });

  // ── Button: Cancel outgoing challenge ──────────────────────────────────────
  document.getElementById('btn-cancel-challenge')?.addEventListener('click', () => {
    modalPending?.classList.remove('visible');
    window.arenaWS.send('CANCEL_CHALLENGE', { target_uid: currentOpponentUid });
  });

  // ── Internal: show incoming challenge modal with countdown ─────────────────
  function _showIncomingChallenge(fromName) {
    const nameEl = document.getElementById('challenger-name');
    if (nameEl) nameEl.textContent = fromName;
    modalReceived?.classList.add('visible');

    let timeLeft = 30;
    if (countdownText) countdownText.textContent = timeLeft;

    challengeTimer = setInterval(() => {
      timeLeft--;
      if (countdownText) countdownText.textContent = timeLeft;
      if (countdownRing) {
        countdownRing.style.strokeDashoffset = `${188 - (timeLeft / 30) * 188}`;
      }
      if (timeLeft <= 0) {
        clearInterval(challengeTimer);
        modalReceived?.classList.remove('visible');
        if (currentOpponentUid) {
          window.arenaWS.send('DECLINE_CHALLENGE', { challenger_uid: currentOpponentUid });
        }
      }
    }, 1000);
  }

  // ── Internal: show the declined toast ─────────────────────────────────────
  function _showDeclined(reason) {
    const notice = document.getElementById('declined-notice');
    const msg    = document.getElementById('declined-msg');
    if (msg)    msg.textContent = reason;
    if (notice) {
      notice.classList.add('visible');
      setTimeout(() => notice.classList.remove('visible'), 4000);
    }
  }
});
