/**
 * ws-client.js — Unified WebSocket Hub
 *
 * Two modes:
 *   lobby  → /ws/lobby?token=...        (matchmaking + presence)
 *   room   → /ws/room/{id}?token=...    (live game)
 *
 * Usage:
 *   window.arenaWS.connect();               // call from lobby.html
 *   window.arenaWS.connectRoom(roomId);     // call from game.html
 *   window.arenaWS.send('TYPE', payload);   // send on whichever socket is open
 *   window.arenaWS.addListener(fn);         // subscribe to incoming messages
 */
class ArenaWS {
  constructor() {
    this.socket    = null;
    this.listeners = new Set();
    this._mode     = 'lobby';   // 'lobby' | 'room'
    this._autoReconnect = false;
  }

  // ── Connect to the lobby WebSocket ────────────────────────────────────────
  connect() {
    const token = sessionStorage.getItem('jwt');
    if (!token) return;
    this._mode         = 'lobby';
    this._autoReconnect = true;
    const url = this._buildUrl(`/ws/lobby`);
    this._open(url);
  }

  // ── Connect to a game room WebSocket ──────────────────────────────────────
  connectRoom(roomId) {
    const token = sessionStorage.getItem('jwt');
    if (!token) return;
    this._mode          = 'room';
    this._autoReconnect = false; 
    const url = this._buildUrl(`/ws/room/${roomId}`);
    this._open(url);
  }

  // ── Internal: open (or replace) a WebSocket ───────────────────────────────
  _open(url) {
    if (this.socket) {
      this.socket.onclose = null;
      this.socket.close();
    }

    console.log(`🔌 WS connecting [${this._mode}]:`, url);
    this.socket = new WebSocket(url);

    this.socket.onopen = () => {
      console.log(`🟢 WS open [${this._mode}]`);
      this.listeners.forEach(cb => cb({ type: 'WS_CONNECTED', mode: this._mode }));
    };

    this.socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log('📥 WS recv:', data);
        this.listeners.forEach(cb => cb(data));
      } catch (err) {
        console.error('WS parse error:', err);
      }
    };

    this.socket.onclose = (evt) => {
      console.log(`🔴 WS closed [${this._mode}] code=${evt.code}`);
      this.listeners.forEach(cb => cb({ type: 'WS_DISCONNECTED', mode: this._mode }));
      if (this._autoReconnect && this._mode === 'lobby') {
        setTimeout(() => this.connect(), 2000);
      }
    };

    this.socket.onerror = (err) => {
      console.error('WS error:', err);
    };
  }

  // ── Build a ws:// or wss:// URL ───────────────────────────────────────────
  _buildUrl(path) {
    const token   = sessionStorage.getItem('jwt');
    const proto   = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host    = window.location.host;
    return `${proto}//${host}${path}?token=${encodeURIComponent(token)}`;
  }

  // ── Send a JSON message ───────────────────────────────────────────────────
  send(type, payload = {}) {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({ type, ...payload }));
    } else {
      console.warn('WS send skipped — socket not open:', type, payload);
    }
  }

  // ── Pub/sub ───────────────────────────────────────────────────────────────
  addListener(callback)    { this.listeners.add(callback); }
  removeListener(callback) { this.listeners.delete(callback); }
}

window.arenaWS = new ArenaWS();

(function autoConnect() {
  const path = window.location.pathname;
  if (path.includes('game.html')) {
    return;
  }
  window.arenaWS.connect();
})();
