/**
 * lobby.js
 * Renders the player grid from WebSocket events and wires Challenge buttons.
 */
document.addEventListener('DOMContentLoaded', () => {
  const token = sessionStorage.getItem('jwt');
  if (!token) {
    window.location.href = 'login.html';
    return;
  }

  const userGrid    = document.getElementById('user-grid');
  const gridEmpty   = document.getElementById('grid-empty');
  const playerCount = document.getElementById('player-count');
  const selfUsername= document.getElementById('self-username');
  const btnLeave    = document.getElementById('btn-leave');

  const localName = sessionStorage.getItem('username') || 'YOU';
  const localUid  = sessionStorage.getItem('uid')      || '';

  if (selfUsername) selfUsername.textContent = localName;
  let activeUsers = [{ uid: localUid, name: localName, status: 'online', isSelf: true }];
  renderUserGrid(activeUsers);

  btnLeave?.addEventListener('click', () => {
    sessionStorage.clear();
    window.location.href = 'login.html';
  });

  // ── WebSocket listeners ────────────────────────────────────────────────────
  window.arenaWS.addListener((event) => {
    switch (event.type) {

      case 'WS_CONNECTED':
        _setWsStatus(true);
        break;

      case 'WS_DISCONNECTED':
        _setWsStatus(false);
        break;

      case 'LOBBY_STATE': {
        const others = (event.players || []).map(p => ({
          uid:    p.uid,
          name:   p.name || p.uid,
          status: 'online',
          isSelf: false,
        }));
        activeUsers = [
          { uid: localUid, name: localName, status: 'online', isSelf: true },
          ...others,
        ];
        renderUserGrid(activeUsers);
        break;
      }

      case 'PLAYER_JOINED':
        if (!activeUsers.find(u => u.uid === event.uid)) {
          activeUsers.push({
            uid:    event.uid,
            name:   event.name || event.uid,
            status: 'online',
            isSelf: false,
          });
          renderUserGrid(activeUsers);
        }
        break;

      case 'PLAYER_LEFT':
        activeUsers = activeUsers.filter(u => u.uid !== event.uid);
        renderUserGrid(activeUsers);
        break;
    }
  });

  // ── Render ─────────────────────────────────────────────────────────────────
  function renderUserGrid(users) {
    if (playerCount) playerCount.textContent = users.length;
    if (!userGrid) return;

    userGrid.innerHTML = '';
    if (users.length === 0) {
      if (gridEmpty) userGrid.appendChild(gridEmpty);
      return;
    }
    users.forEach(user => userGrid.appendChild(createUserCard(user)));
  }

  function createUserCard(user) {
    const card = document.createElement('div');
    card.id        = `user-${user.uid}`;
    card.className = `user-card ${user.isSelf ? 'user-card--self' : ''}`;
    card.setAttribute('data-status', user.status);

    const initial      = (user.name || '?').charAt(0).toUpperCase();
    const safeName     = user.name.replace(/'/g, "\\'");
    const challengeBtn = user.isSelf
      ? ''
      : `<button class="btn-challenge"
           onclick="window.initiateChallenge('${user.uid}', '${safeName}')">
           Challenge
         </button>`;

    card.innerHTML = `
      <div class="user-card__avatar">${initial}</div>
      <div class="user-card__name">${user.name}</div>
      <div class="user-card__status-badge">● ONLINE</div>
      ${challengeBtn}
    `;
    return card;
  }

  function _setWsStatus(connected) {
    const dot   = document.getElementById('ws-dot');
    const label = document.getElementById('ws-label');
    if (dot) {
      dot.classList.toggle('status-dot--online',  connected);
      dot.classList.toggle('status-dot--offline', !connected);
    }
    if (label) label.textContent = connected ? 'CONNECTED' : 'RECONNECTING…';
  }
});
