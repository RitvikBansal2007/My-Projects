/**
 * game.js — Full 2.5D Tic-Tac-Toe Engine (WebSocket-driven)
 *
 * On load:
 *   1. Read room_id / symbol / opponent from URL params (set by matchmaking.js)
 *   2. Connect to /ws/room/{room_id} via arenaWS.connectRoom()
 *   3. Receive GAME_STATE from server → render board + configure trays
 *   4. Drag-and-drop sends MOVE → server validates → MOVE_ACCEPTED updates both clients
 *   5. GAME_OVER shows result + Elo delta
 */

// ── Read game params from URL ───────────────────────────────────────────────
const _p            = new URLSearchParams(window.location.search);
const ROOM_ID       = _p.get('room_id')  || sessionStorage.getItem('room_id');
let   MY_SYMBOL     = _p.get('symbol')   || sessionStorage.getItem('my_symbol')     || 'X';
const OPPONENT_NAME = _p.get('opponent') || sessionStorage.getItem('opponent_name') || 'OPPONENT';
const MY_UID        = sessionStorage.getItem('uid') || '';

// ── Game state (authoritative copy mirrors server) ──────────────────────────
let gameState  = null;   
let myTurn     = false;
let gameActive = false;
let draggedPiece = null;
let disconnectTimer = null; 

// ── DOM entry point ──────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  if (!ROOM_ID) {
    console.error('No room_id — redirecting to lobby.');
    window.location.href = 'lobby.html';
    return;
  }

  _setText('opponent-name', OPPONENT_NAME);
  _setText('my-symbol',     `You play: ${MY_SYMBOL}`);
  _setText('turn-indicator','Connecting…');
  _setText('game-id',       `GAME ID: ${ROOM_ID}`);

  initTrays(MY_SYMBOL);

  window.arenaWS.connectRoom(ROOM_ID);
  window.arenaWS.addListener(handleWSMessage);

  document.getElementById('btn-resign')?.addEventListener('click', () => {
    if (!gameActive) return;
    if (confirm('Resign and forfeit this match?')) {
      window.arenaWS.send('RESIGN');
    }
  });

  document.getElementById('btn-return-lobby')?.addEventListener('click', () => {
    window.location.href = 'lobby.html';
  });

  initDragAndDrop();
});

// ── WebSocket message handler ────────────────────────────────────────────────
function handleWSMessage(data) {
  switch (data.type) {

    case 'GAME_STATE':
    case 'GAME_START':
      gameActive = data.active !== false;
      myTurn     = data.your_turn === true;
      gameState  = data.state;

      if (data.symbol) {
        MY_SYMBOL = data.symbol;
        sessionStorage.setItem('my_symbol', MY_SYMBOL);
        _setText('my-symbol', `You play: ${MY_SYMBOL}`);
        initTrays(MY_SYMBOL);
      }

      renderBoard(gameState.board);
      updateTurnUI(myTurn);
      if (data.opponent_name) _setText('opponent-name', data.opponent_name);
      break;

    case 'MOVE_ACCEPTED':
      gameState = data.state;
      renderBoard(gameState.board);
      myTurn = (data.by !== MY_UID);
      updateTurnUI(myTurn);
      break;

    case 'MOVE_REJECTED':
      showToast(`Move rejected: ${data.reason}`, 'error');
      renderBoard(gameState?.board || new Array(9).fill(null));
      myTurn = true;
      updateTurnUI(true);
      break;

    case 'GAME_OVER':
      gameActive = false;
      myTurn     = false;
      updateTurnUI(false);
      hideDisconnectBanner();  
      showGameOver(data);
      break;

    // ── Opponent closed their browser ────────────────────────────────────
    case 'OPPONENT_DISCONNECTED':
      showDisconnectBanner(data.grace_seconds || 30);
      break;

    // ── Opponent came back within grace period ──────────────────────────
    case 'OPPONENT_RECONNECTED':
      hideDisconnectBanner();
      showToast('Opponent reconnected!', 'success');
      break;

    case 'WS_DISCONNECTED':
      _setText('turn-indicator', 'Reconnecting…');
      break;
  }
}

// ── Board rendering ──────────────────────────────────────────────────────────
function renderBoard(board) {
  const cells = document.querySelectorAll('.cell');
  cells.forEach((cell, idx) => {
    cell.querySelectorAll('.piece--placed').forEach(p => p.remove());
    cell.querySelectorAll('.drop-ripple').forEach(r => r.remove());
    cell.classList.remove('cell--winning');

    const occupant = board[idx];
    if (occupant) {
      const sym = gameState?.symbols?.[occupant]
                  || (occupant === MY_UID ? MY_SYMBOL : _opponentSymbol());
      const piece = document.createElement('div');
      piece.className = `piece piece--${sym.toLowerCase()} piece--placed`;
      piece.textContent = sym;
      cell.appendChild(piece);
    }
  });

  setDraggable(myTurn && gameActive);
}

function _opponentSymbol() {
  return MY_SYMBOL === 'X' ? 'O' : 'X';
}

// ── Tray initialization ─────────────────────────────────────────────────────
function initTrays(symbol) {
  const oppSymbol = symbol === 'X' ? 'O' : 'X';
  const trayMy    = document.getElementById('tray-my');
  const trayOpp   = document.getElementById('tray-opp');

  if (trayMy) {
    trayMy.setAttribute('data-label', `YOUR PIECES (${symbol})`);
    trayMy.innerHTML = '';
    for (let i = 0; i < 5; i++) {
      const p = document.createElement('div');
      p.className = `piece piece--${symbol.toLowerCase()}`;
      p.textContent = symbol;
      p.dataset.symbol = symbol;
      p.setAttribute('draggable', 'true');
      trayMy.appendChild(p);
    }
  }

  if (trayOpp) {
    trayOpp.setAttribute('data-label', `OPPONENT (${oppSymbol})`);
    trayOpp.innerHTML = '';
    for (let i = 0; i < 5; i++) {
      const p = document.createElement('div');
      p.className = `piece piece--${oppSymbol.toLowerCase()}`;
      p.textContent = oppSymbol;
      p.dataset.symbol = oppSymbol;
      p.setAttribute('draggable', 'false');
      p.style.opacity = '0.4';
      p.style.cursor  = 'default';
      trayOpp.appendChild(p);
    }
  }
  initDragAndDrop();
}

// ── Turn UI ──────────────────────────────────────────────────────────────────
function updateTurnUI(isMyTurn) {
  const el = document.getElementById('turn-indicator');
  if (el) {
    el.textContent  = isMyTurn ? 'YOUR TURN' : `${OPPONENT_NAME}'s TURN`;
    el.className = `turn-indicator ${isMyTurn ? 'turn-indicator--active' : 'turn-indicator--waiting'}`;
  }
  setDraggable(isMyTurn && gameActive);
}

function setDraggable(enabled) {
  document.querySelectorAll('#tray-my .piece').forEach(p => {
    if (p.classList.contains('piece--used')) {
      p.style.opacity       = '0';
      p.style.pointerEvents = 'none';
      return;
    }
    p.style.opacity       = enabled ? '1'         : '0.4';
    p.style.pointerEvents = enabled ? 'auto'      : 'none';
    p.style.cursor        = enabled ? 'grab'      : 'not-allowed';
    p.setAttribute('draggable', enabled ? 'true' : 'false');
  });
}

// ── Drag-and-Drop ────────────────────────────────────────────────────────────
function initDragAndDrop() {
  document.querySelectorAll('#tray-my .piece').forEach(piece => {
    const freshPiece = piece.cloneNode(true);
    piece.parentNode.replaceChild(freshPiece, piece);

    freshPiece.addEventListener('dragstart', (e) => {
      if (!myTurn || !gameActive) { e.preventDefault(); return; }
      draggedPiece = freshPiece;
      freshPiece.classList.add('piece--grabbed');
      e.dataTransfer.setData('text/plain', freshPiece.dataset.symbol || MY_SYMBOL);
      e.dataTransfer.effectAllowed = 'move';
    });

    freshPiece.addEventListener('dragend', () => {
      freshPiece.classList.remove('piece--grabbed');
      draggedPiece = null;
    });
  });

  document.querySelectorAll('.cell').forEach(cell => {
    cell.addEventListener('dragover', (e) => {
      e.preventDefault();
      const idx = parseInt(cell.dataset.index, 10);
      if (gameState && gameState.board[idx] === null && myTurn && gameActive) {
        cell.classList.add('cell--valid-hover');
        e.dataTransfer.dropEffect = 'move';
      }
    });

    cell.addEventListener('dragleave', () => {
      cell.classList.remove('cell--valid-hover');
    });

    cell.addEventListener('drop', (e) => {
      e.preventDefault();
      cell.classList.remove('cell--valid-hover');

      const cellIdx = parseInt(cell.dataset.index, 10);
      if (!myTurn || !gameActive) return;
      if (gameState && gameState.board[cellIdx] !== null) return;

      _placeSymbol(cell, MY_SYMBOL);
      _depleteTrayPiece();
      myTurn = false;
      updateTurnUI(false);

      window.arenaWS.send('MOVE', { payload: { cell: cellIdx } });
    });
  });
}

function _placeSymbol(cell, symbol) {
  const piece = document.createElement('div');
  piece.className = `piece piece--${symbol.toLowerCase()} piece--placed piece--snapping`;
  piece.textContent = symbol;
  cell.appendChild(piece);

  const ripple = document.createElement('div');
  ripple.className = 'drop-ripple';
  cell.appendChild(ripple);
  ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
}

function _depleteTrayPiece() {
  const tray = document.getElementById('tray-my');
  if (!tray) return;
  const pieces = [...tray.querySelectorAll('.piece:not(.piece--used)')];
  if (pieces.length > 0) {
    pieces[pieces.length - 1].classList.add('piece--used');
  }
}

// ── Game Over ────────────────────────────────────────────────────────────────
function showGameOver(data) {
  const isWinner = data.winner === MY_UID;
  const isDraw   = data.reason === 'DRAW' || data.winner === null;

  const title = isDraw ? 'DRAW' : isWinner ? 'VICTORY!' : 'DEFEATED';
  const eloChange = data.your_delta !== undefined 
    ? data.your_delta 
    : (isWinner ? (data.winner_delta || 0) : (data.loser_delta || 0));

  const reasonMap = {
    FORFEIT: 'Opponent forfeited',
    RESIGN:  'Opponent resigned',
    DRAW:    'Board full — it\'s a draw!',
    NORMAL:  '',
  };

  _setText('game-over-title',  title);
  _setText('game-over-reason', reasonMap[data.reason] || '');
  _setText('elo-change', eloChange > 0 ? `+${eloChange} ELO` : `${eloChange} ELO`);

  if (isWinner && !isDraw) _highlightWinLine();

  document.getElementById('game-over-overlay')?.classList.add('visible');
}

function _highlightWinLine() {
  if (!gameState) return;
  const WIN_LINES = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6],
  ];
  const cells = document.querySelectorAll('.cell');
  for (const line of WIN_LINES) {
    if (line.every(i => gameState.board[i] === MY_UID)) {
      line.forEach(i => cells[i]?.classList.add('cell--winning'));
      break;
    }
  }
}

// ── Disconnect banner ────────────────────────────────────────────────────────
function showDisconnectBanner(graceSeconds) {
  const banner   = document.getElementById('disconnect-banner');
  const countEl  = document.getElementById('disconnect-countdown');
  const progress = document.getElementById('disconnect-progress');
  if (!banner) return;

  if (disconnectTimer) clearInterval(disconnectTimer);

  let remaining = graceSeconds;
  banner.style.display = 'block';
  if (countEl) countEl.textContent = `${remaining}s`;
  if (progress) progress.style.width = '100%';

  _setText('turn-indicator', '⚠ OPPONENT DISCONNECTED');

  disconnectTimer = setInterval(() => {
    remaining--;
    if (countEl) countEl.textContent = `${remaining}s`;
    if (progress) progress.style.width = `${(remaining / graceSeconds) * 100}%`;
    if (remaining <= 0) {
      clearInterval(disconnectTimer);
      disconnectTimer = null;
    }
  }, 1000);

  showToast('Opponent disconnected! Waiting for reconnect…', 'error');
}

function hideDisconnectBanner() {
  const banner = document.getElementById('disconnect-banner');
  if (banner) banner.style.display = 'none';
  if (disconnectTimer) {
    clearInterval(disconnectTimer);
    disconnectTimer = null;
  }
}

// ── Utility ──────────────────────────────────────────────────────────────────
function _setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function showToast(msg, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.style.cssText = 'padding:10px 18px;border-radius:4px;font-size:0.8rem;letter-spacing:0.08em;' +
    (type === 'error' ? 'background:#b52020;color:#ffe0e0;'
     : type === 'success' ? 'background:#1e4620;color:#a0f0a0;'
     : 'background:#1a5faa;color:#d0e8ff;');
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
