/**
 * leaderboard.js — Fetches and renders the ELO leaderboard
 *
 * Fetches GET /leaderboard/ and renders a ranked table.
 * Auto-refreshes every 30 seconds.
 */
document.addEventListener('DOMContentLoaded', () => {
  const token = sessionStorage.getItem('jwt');
  if (!token) {
    window.location.href = 'login.html';
    return;
  }

  const localUid = sessionStorage.getItem('uid') || '';
  const tableBody = document.getElementById('lb-table-body');
  const loadingEl = document.getElementById('lb-loading');
  const emptyEl   = document.getElementById('lb-empty');
  const refreshLabel = document.getElementById('lb-refresh-label');

  let refreshTimer = null;
  let countdown = 30;

  // ── Initial fetch ──────────────────────────────────────────────────────────
  fetchLeaderboard();

  // ── Auto-refresh every 30 seconds ─────────────────────────────────────────
  refreshTimer = setInterval(() => {
    countdown--;
    if (refreshLabel) refreshLabel.textContent = `Auto-refresh in ${countdown}s`;
    if (countdown <= 0) {
      countdown = 30;
      fetchLeaderboard();
    }
  }, 1000);

  // ── Manual refresh button ─────────────────────────────────────────────────
  document.getElementById('btn-refresh')?.addEventListener('click', () => {
    countdown = 30;
    fetchLeaderboard();
  });

  // ── Back to lobby ─────────────────────────────────────────────────────────
  document.getElementById('btn-back-lobby')?.addEventListener('click', () => {
    window.location.href = 'lobby.html';
  });

  // ── Fetch leaderboard data ────────────────────────────────────────────────
  async function fetchLeaderboard() {
    try {
      showLoading(true);
      const resp = await fetch('/leaderboard/');
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      renderTable(data);
    } catch (err) {
      console.error('Failed to fetch leaderboard:', err);
      showEmpty('Failed to load leaderboard. Retrying…');
    } finally {
      showLoading(false);
    }
  }

  // ── Render the table rows ─────────────────────────────────────────────────
  function renderTable(players) {
    if (!tableBody) return;

    if (!players || players.length === 0) {
      showEmpty('No players found. Play a match to appear on the leaderboard!');
      return;
    }

    if (emptyEl) emptyEl.style.display = 'none';
    tableBody.innerHTML = '';

    players.forEach((player, idx) => {
      const tr = document.createElement('tr');
      tr.style.animationDelay = `${idx * 0.04}s`;
      if (player.uid === localUid) {
        tr.classList.add('lb-row--self');
      }

      const rank = player.rank || idx + 1;
      const initial = (player.name || '?').charAt(0).toUpperCase();
      let rankDisplay;
      if (rank === 1)      rankDisplay = '👑';
      else if (rank === 2) rankDisplay = '🥈';
      else if (rank === 3) rankDisplay = '🥉';
      else                 rankDisplay = rank;

      tr.innerHTML = `
        <td><span class="rank-cell">${rankDisplay}</span></td>
        <td>
          <div class="lb-player-cell">
            <div class="lb-player-avatar">${initial}</div>
            <div>
              <div class="lb-player-name">${_escapeHtml(player.name)}</div>
              <div class="lb-player-uid">ID: ${_escapeHtml(player.uid)}</div>
            </div>
          </div>
        </td>
        <td><span class="lb-elo">${player.elo}</span></td>
      `;
      tableBody.appendChild(tr);
    });
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  function showLoading(show) {
    if (loadingEl) loadingEl.style.display = show ? 'flex' : 'none';
  }

  function showEmpty(msg) {
    if (emptyEl) {
      emptyEl.textContent = msg;
      emptyEl.style.display = 'block';
    }
    if (tableBody) tableBody.innerHTML = '';
  }

  function _escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }
});
