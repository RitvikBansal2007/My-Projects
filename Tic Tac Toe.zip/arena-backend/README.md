# Identity-Verified Multiplayer Arena

This guide provides step-by-step instructions to run the **ARENA Backend** and its associated WebSocket/HTTP services locally from a freshly cloned repository.

---

## Prerequisites

You will need the following installed on your system:
- **Python 3.13+**
- **uv** (A fast Python package and project manager)
- **MySQL** (Relational Database)
- **MongoDB 7.0** (NoSQL Database for image storage)

### Installing Prerequisites

**For macOS:**
```bash
# Install Homebrew (if not already installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install uv
brew install uv

# Install MySQL
brew install mysql

# Install MongoDB 7.0
brew tap mongodb/brew
brew install mongodb-community@7.0
```

**For Linux (Ubuntu/Debian):**
```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install MySQL
sudo apt update
sudo apt install mysql-server
sudo systemctl start mysql

# Install MongoDB
sudo apt-get install gnupg curl
curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | \
   sudo gpg -o /usr/share/keyrings/mongodb-server-7.0.gpg \
   --dearmor
echo "deb [ arch=amd64,arm64 signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

---

## Step 1: Start Database Services

### macOS

**Start MySQL:**
```bash
brew services start mysql
```

**Start MongoDB:**

> ⚠️ **Known Issue on macOS:** `brew services start mongodb-community@7.0` may fail with `Bootstrap failed: 5: Input/output error`. This is a known macOS LaunchAgent bug caused by leftover socket/permission issues from previous runs. Follow the steps below to fix it.

**Step 1a — Clean up leftover socket file (if it exists):**
```bash
sudo rm -f /tmp/mongodb-27017.sock
```

**Step 1b — Fix data directory ownership (if MongoDB was ever run with `sudo`):**
```bash
sudo chown -R $(whoami):admin /opt/homebrew/var/mongodb
sudo chown -R $(whoami):admin /opt/homebrew/var/log/mongodb
```

**Step 1c — Start MongoDB directly in the background (bypasses the broken LaunchAgent):**
```bash
/opt/homebrew/opt/mongodb-community@7.0/bin/mongod \
  --dbpath /opt/homebrew/var/mongodb \
  --logpath /opt/homebrew/var/log/mongodb/output.log \
  --logappend \
  --bind_ip 127.0.0.1 \
  --port 27017 &
```

**Step 1d — Verify MongoDB is running:**
```bash
sleep 2 && /opt/homebrew/bin/mongosh --eval "db.runCommand({ping:1})" --quiet
# Expected output: { ok: 1 }
```

> 📝 **Note:** If you reboot your Mac, MongoDB will stop. Re-run the Step 1c command to start it again before running the project.

### Linux

```bash
sudo systemctl start mysql
sudo systemctl start mongod

# Verify both are running
sudo systemctl status mysql
sudo systemctl status mongod
```

---

## Step 2: MySQL Database Setup

Open the MySQL shell (you will be prompted for the root password — press Enter if none is set):
```bash
mysql -u root -p
```

Run the following SQL commands to create the database and user:
```sql
CREATE DATABASE IF NOT EXISTS arena_db;
CREATE USER IF NOT EXISTS 'arena_user'@'localhost' IDENTIFIED BY 'Arena1234!';
GRANT ALL PRIVILEGES ON arena_db.* TO 'arena_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

> 📝 MongoDB does not need pre-setup — the database and collections are created automatically on first use.

---

## Step 3: Environment Variables

Navigate to the backend directory:
```bash
cd arena-backend
```

Copy the example environment file:
```bash
cp .env.example .env
```

Open `.env` and ensure it contains the following values (these match the password set in Step 2):

```env
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=arena_user
MYSQL_PASSWORD=Arena1234!
MYSQL_DB=arena_db

MONGO_URI=mongodb://localhost:27017
MONGO_DB=arena_db

SESSION_SECRET_KEY=put_any_random_32_character_string_here
SESSION_TTL_SECONDS=3600

DEBUG=true
```

> ⚠️ `SESSION_SECRET_KEY` must be at least 32 characters. You can generate one with:
> ```bash
> python3 -c "import secrets; print(secrets.token_hex(16))"
> ```

---

## Step 4: Install Dependencies & Run Migrations

Run the following inside the `arena-backend` directory:

```bash
# Install all Python dependencies into a local virtual environment
uv sync

# Apply database migrations to create all required MySQL tables
uv run alembic upgrade head
```

> ⚠️ **If `alembic upgrade head` fails** with `Can't locate revision` on a fresh database, check the **Troubleshooting Common Issues** section below.

---

## Step 5: Populate Data (Harvester)

Run the harvester script to populate both MySQL and MongoDB from the provided batch data:
```bash
uv run python -m app.phase1_harvester.harvester --csv data/batch_data.csv --concurrency 8
```

---

## Step 6: Start the Server

Start the FastAPI + Uvicorn server (handles both HTTP and WebSocket connections):

```bash
uv run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

The application will be available at:

**[http://127.0.0.1:8000/static/index.html](http://127.0.0.1:8000/static/index.html)**

---

## Troubleshooting Common Issues

### 1. MySQL "Access Denied" or Password Reset Loop

If you installed MySQL via Homebrew and get locked out with `ERROR 1045 (28000): Access denied for user 'root'@'localhost'`, or if MySQL refuses an empty password due to policy (`ERROR 1819`), follow these steps precisely to reset your password and initialize the database.

**Step 1: Stop MySQL and Boot into Safe Mode**
Start the server without the grant tables to bypass the password check:
```bash
brew services stop mysql
sudo pkill mysqld
/opt/homebrew/opt/mysql/bin/mysqld_safe --skip-grant-tables &
```
*(Wait a few seconds for it to start up in the background).*

**Step 2: Log in and Configure the Database**
Log in as root (no password required):
```bash
mysql -u root
```

Run the following SQL commands exactly. We use `Root1234!` and `Arena1234!` to satisfy strict MySQL password requirements:
```sql
FLUSH PRIVILEGES;
ALTER USER 'root'@'localhost' IDENTIFIED BY 'Root1234!';
CREATE DATABASE IF NOT EXISTS arena_db;
CREATE USER IF NOT EXISTS 'arena_user'@'localhost' IDENTIFIED BY 'Arena1234!';
GRANT ALL PRIVILEGES ON arena_db.* TO 'arena_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

**Step 3: Restart MySQL Normally**
Kill the safe-mode instance and restart standard MySQL using Homebrew:
```bash
sudo pkill mysqld
brew services start mysql
```
*(Make sure to update your `.env` file to use `Arena1234!` as the password for `arena_user`.)*

### 2. Alembic "Can't locate revision" Error

If you see an error like `FAILED: Can't locate revision identified by 'xxxxxx'` when running `uv run alembic upgrade head`, it means the migration history in your MySQL database does not match the physical Python files in your `alembic/versions/` directory.

**Step 1: Nuke the local database**
This will clear the desynced `alembic_version` table from MySQL:
```bash
mysql -u arena_user -p -e "DROP DATABASE arena_db; CREATE DATABASE arena_db;"
```
*(Enter `Arena1234!` when prompted for the password.)*

**Step 2: Clear out corrupted physical migration files**
Delete any broken or out-of-sync migration scripts from the repository:
```bash
rm -rf alembic/versions/*.py
```

**Step 3: Generate a brand new unified migration**
Let Alembic look at your SQLAlchemy models and generate a fresh schema script:
```bash
uv run alembic revision --autogenerate -m "initial schema"
```

**Step 4: Apply the new schema to your database**
```bash
uv run alembic upgrade head
```
Your database and codebase will now be perfectly synced!

---

## Quick Reference — All Commands in Order

```bash
# macOS only — start MySQL
brew services start mysql

# macOS only — start MongoDB (use this if brew services fails)
sudo rm -f /tmp/mongodb-27017.sock
sudo chown -R $(whoami):admin /opt/homebrew/var/mongodb
sudo chown -R $(whoami):admin /opt/homebrew/var/log/mongodb
/opt/homebrew/opt/mongodb-community@7.0/bin/mongod \
  --dbpath /opt/homebrew/var/mongodb \
  --logpath /opt/homebrew/var/log/mongodb/output.log \
  --logappend --bind_ip 127.0.0.1 --port 27017 &

# Linux only — start services
# sudo systemctl start mysql && sudo systemctl start mongod

# Create MySQL DB and user
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS arena_db; CREATE USER IF NOT EXISTS 'arena_user'@'localhost' IDENTIFIED BY 'Arena1234!'; GRANT ALL PRIVILEGES ON arena_db.* TO 'arena_user'@'localhost'; FLUSH PRIVILEGES;"

# Set up the project
cd arena-backend
cp .env.example .env
# Edit .env: set MYSQL_PASSWORD=Arena1234! and fill in SESSION_SECRET_KEY

# Install deps and run migrations
uv sync
uv run alembic upgrade head

# Populate database from batch data
uv run python -m app.phase1_harvester.harvester --csv data/batch_data.csv --concurrency 8

# Start the server
uv run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

---

## Assumptions Made During Development
1. **`is_online` Status Context:** The `is_online` flag tracks users available for matchmaking. When a user enters a game, their lobby WebSocket disconnects and `is_online` is set to `FALSE`.
2. **Webcam Environment:** User faces are well-lit and recognizable for face recognition login. A standard webcam is required.
3. **Database Availability:** MySQL and MongoDB are running locally on their default ports (3306 and 27017).

---

## Database Schemas Reference

### MySQL Schema
```sql
CREATE TABLE players (
    id              VARCHAR(20)   PRIMARY KEY,
    name            VARCHAR(200)  NOT NULL,
    elo_rating      INT           NOT NULL DEFAULT 1200,
    is_online       BOOLEAN       NOT NULL DEFAULT FALSE,
    mongo_image_id  VARCHAR(24)   NOT NULL,
    website_url     VARCHAR(300),
    created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE match_history (
    id              BIGINT        AUTO_INCREMENT PRIMARY KEY,
    room_id         VARCHAR(36)   NOT NULL,
    winner_id       VARCHAR(20)   REFERENCES players(id),
    loser_id        VARCHAR(20)   REFERENCES players(id),
    winner_delta    INT           NOT NULL,
    loser_delta     INT           NOT NULL,
    forfeit         BOOLEAN       NOT NULL DEFAULT FALSE,
    draw            BOOLEAN       NOT NULL DEFAULT FALSE,
    played_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE harvest_errors (
    id              BIGINT        AUTO_INCREMENT PRIMARY KEY,
    source_row      INT,
    uid             VARCHAR(20),
    website_url     VARCHAR(300),
    error_message   TEXT,
    occurred_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### MongoDB Schema
**Collection:** `player_images`
```js
{
  _id:        ObjectId,
  uid:        String,          // Matches players.id
  image_data: BinData,         // Raw bytes
  mime_type:  String,
  source_url: String,
  created_at: ISODate
}
```
