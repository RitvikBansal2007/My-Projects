"""initial schema

Revision ID: d04a7d5c4b31
Revises: 
Create Date: 2026-04-10 02:57:21.154123

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'd04a7d5c4b31'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.create_table('harvest_errors',
    sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('uid', sa.String(length=20), nullable=True),
    sa.Column('website_url', sa.String(length=300), nullable=True),
    sa.Column('error_message', sa.Text(), nullable=True),
    sa.Column('occurred_at', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_table('players',
    sa.Column('id', sa.String(length=20), nullable=False),
    sa.Column('name', sa.String(length=200), nullable=False),
    sa.Column('elo_rating', sa.Integer(), nullable=False),
    sa.Column('mongo_image_id', sa.String(length=24), nullable=False),
    sa.Column('website_url', sa.String(length=300), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_table('match_history',
    sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
    sa.Column('room_id', sa.String(length=36), nullable=False),
    sa.Column('winner_id', sa.String(length=20), nullable=False),
    sa.Column('loser_id', sa.String(length=20), nullable=False),
    sa.Column('winner_delta', sa.Integer(), nullable=False),
    sa.Column('loser_delta', sa.Integer(), nullable=False),
    sa.Column('forfeit', sa.Boolean(), nullable=False),
    sa.Column('played_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['loser_id'], ['players.id'], ),
    sa.ForeignKeyConstraint(['winner_id'], ['players.id'], ),
    sa.PrimaryKeyConstraint('id')
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_table('match_history')
    op.drop_table('players')
    op.drop_table('harvest_errors')
