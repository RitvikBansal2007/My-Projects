"""add is_online to players, draw to match_history, nullable winner/loser

Revision ID: a1b2c3d4e5f6
Revises: d04a7d5c4b31
Create Date: 2026-04-17 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, Sequence[str], None] = 'd04a7d5c4b31'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('players',
        sa.Column('is_online', sa.Boolean(), nullable=False, server_default=sa.text('0'))
    )

    op.add_column('match_history',
        sa.Column('draw', sa.Boolean(), nullable=False, server_default=sa.text('0'))
    )

    op.alter_column('match_history', 'winner_id',
        existing_type=sa.String(length=20),
        nullable=True
    )
    op.alter_column('match_history', 'loser_id',
        existing_type=sa.String(length=20),
        nullable=True
    )


def downgrade() -> None:
    op.alter_column('match_history', 'loser_id',
        existing_type=sa.String(length=20),
        nullable=False
    )
    op.alter_column('match_history', 'winner_id',
        existing_type=sa.String(length=20),
        nullable=False
    )
    op.drop_column('match_history', 'draw')
    op.drop_column('players', 'is_online')
