import json
import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from sqlalchemy import update

from app.phase2_auth.session import validate_session
from app.phase3_arena.lobby  import lobby_manager
from app.phase3_arena.room   import create_room, get_room, remove_room, FORFEIT_GRACE_SECONDS
from app.database.mysql      import AsyncSessionLocal
from app.database.models     import Player

arena_router = APIRouter(tags=["arena"])



# /ws/lobby  — presence + matchmaking

@arena_router.websocket("/ws/lobby")
async def lobby_endpoint(ws: WebSocket, token: str = Query(...)):
    session = validate_session(token)
    if not session:
        await ws.close(code=4001)
        return

    uid:  str = session["uid"]
    name: str = session["name"]
    await lobby_manager.connect(uid, name, ws)

    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await ws.send_json({"type": "ERROR", "reason": "Invalid JSON."})
                continue

            msg_type = msg.get("type")

            #Challenge send
            if msg_type == "CHALLENGE":
                await lobby_manager.send_challenge(uid, msg.get("target_uid", ""))

            #Challenge accept
            elif msg_type == "ACCEPT_CHALLENGE":
                challenger_uid = msg.get("challenger_uid", "")
                result = await lobby_manager.accept_challenge(uid, challenger_uid)
                if result:
                    c_uid, a_uid = result
                    ws_c, name_c = lobby_manager.pop_player(c_uid)
                    ws_a, name_a = lobby_manager.pop_player(a_uid)
                    if ws_c and ws_a:
                        room = create_room(c_uid, name_c, a_uid, name_a, ws_c, ws_a)
                        await room.start()
                    else:
                        await ws.send_json({"type": "ERROR", "reason": "Opponent disconnected."})
                else:
                    await ws.send_json({"type": "ERROR", "reason": "No pending challenge from that player."})

            #Challenge decline
            elif msg_type == "DECLINE_CHALLENGE":
                challenger_uid = msg.get("challenger_uid", "")
                await lobby_manager.decline_challenge(uid, challenger_uid)

            #Challenge cancel (challenger changes mind)
            elif msg_type == "CANCEL_CHALLENGE":
                target_uid = msg.get("target_uid", "")
                await lobby_manager.cancel_challenge(uid, target_uid)

            else:
                await ws.send_json({"type": "ERROR", "reason": f"Unknown type: {msg_type}"})

    except WebSocketDisconnect:
        await lobby_manager.disconnect(uid)
        try:
            async with AsyncSessionLocal() as db:
                await db.execute(
                    update(Player).where(Player.id == uid).values(is_online=False)
                )
                await db.commit()
        except Exception:
            pass


# /ws/room/{room_id}  — active game

@arena_router.websocket("/ws/room/{room_id}")
async def room_endpoint(ws: WebSocket, room_id: str, token: str = Query(...)):
    session = validate_session(token)
    if not session:
        await ws.close(code=4001)
        return

    uid:  str = session["uid"]
    room      = get_room(room_id)

    if not room or uid not in room.players:
        await ws.close(code=4004)
        return

    await ws.accept()

    had_forfeit_timer = uid in room._forfeit_tasks
    room.cancel_forfeit_timer(uid)
    room.players[uid] = ws

    if had_forfeit_timer:
        await room.notify_opponent_reconnect(uid)

    await room.send_state(uid)

    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await ws.send_json({"type": "ERROR", "reason": "Invalid JSON."})
                continue

            msg_type = msg.get("type")

            #Player move
            if msg_type == "MOVE":
                payload        = msg.get("payload", {})
                ok, reason     = room.validate_move(uid, payload)

                if not ok:
                    await ws.send_json({"type": "MOVE_REJECTED", "reason": reason})
                    continue

                result = room.apply_move(uid, payload)

                await room.broadcast({
                    "type":  "MOVE_ACCEPTED",
                    "state": room._get_state(),
                    "by":    uid,
                })

                if result == "DRAW":
                    uid_a, uid_b = room.player_list
                    async with AsyncSessionLocal() as db:
                        from app.phase4_elo.router import record_draw_result
                        draw_deltas = await record_draw_result(
                            uid_a, uid_b, room_id, db
                        )
                    elo_deltas = {
                        "winner_delta": draw_deltas.get("delta_a", 0),
                        "loser_delta":  draw_deltas.get("delta_b", 0),
                    }
                    await room.end(winner_uid=None, reason="DRAW", elo_deltas=elo_deltas)
                    remove_room(room_id)

                elif result is not None:
                    loser_uid = room._opponent(result)
                    async with AsyncSessionLocal() as db:
                        from app.phase4_elo.router import record_match_result
                        elo_deltas = await record_match_result(
                            result, loser_uid, False, room_id, db
                        )
                    await room.end(winner_uid=result, reason="NORMAL", elo_deltas=elo_deltas)
                    remove_room(room_id)

            #Resign
            elif msg_type == "RESIGN":
                opponent = room._opponent(uid)
                async with AsyncSessionLocal() as db:
                    from app.phase4_elo.router import record_match_result
                    elo_deltas = await record_match_result(opponent, uid, False, room_id, db)
                await room.end(winner_uid=opponent, reason="RESIGN", elo_deltas=elo_deltas)
                remove_room(room_id)

            else:
                await ws.send_json({"type": "ERROR", "reason": f"Unknown type: {msg_type}"})

    except WebSocketDisconnect:
        if room.active:
            await room.handle_disconnect(uid)
            async def _delayed_forfeit(disconnected_uid: str, r_id: str):
                await asyncio.sleep(FORFEIT_GRACE_SECONDS + 1)
                r = get_room(r_id)
                if r is None or not r.active:
                    return

                winner_uid = r._opponent(disconnected_uid)

                async with AsyncSessionLocal() as db:
                    from app.phase4_elo.router import record_match_result
                    elo_deltas = await record_match_result(
                        winner_uid, disconnected_uid, True, r_id, db
                    )

                await r.end(winner_uid=winner_uid, reason="FORFEIT", elo_deltas=elo_deltas)
                remove_room(r_id)

            asyncio.create_task(_delayed_forfeit(uid, room_id))

