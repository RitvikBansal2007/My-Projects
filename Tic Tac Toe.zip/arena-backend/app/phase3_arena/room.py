import uuid
import asyncio
from fastapi import WebSocket

FORFEIT_GRACE_SECONDS = 30

WIN_LINES = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], 
    [0, 3, 6], [1, 4, 7], [2, 5, 8],   
    [0, 4, 8], [2, 4, 6],               
]


class GameRoom:
    """
    Authoritative Tic-Tac-Toe game room.
    All state lives here — clients are untrusted.
    Player identifiers are uid strings (e.g. "2025101002").
    """

    def __init__(
        self,
        room_id: str,
        uid_a: str, name_a: str,
        uid_b: str, name_b: str,
        ws_a: WebSocket, ws_b: WebSocket,
    ):
        self.room_id     = room_id
        self.players     = {uid_a: ws_a, uid_b: ws_b}
        self.names       = {uid_a: name_a, uid_b: name_b}
        self.player_list = [uid_a, uid_b]
        self.symbols     = {uid_a: "X", uid_b: "O"}
        self.turn: str   = uid_a         
        self.board       = [None] * 9     
        self.move_history: list[dict] = []
        self.active: bool = True
        self._forfeit_tasks: dict[str, asyncio.Task] = {}

    #State snapshot (sent to clients)

    def _get_state(self) -> dict:
        return {
            "board":   self.board,    
            "symbols": self.symbols, 
            "turn":    self.turn,
        }

    # Startup / reconnect

    async def start(self) -> None:
        """Send GAME_START to both players over their lobby WebSockets."""
        for uid, ws in self.players.items():
            opp = self._opponent(uid)
            try:
                await ws.send_json({
                    "type":          "GAME_START",
                    "room_id":       self.room_id,
                    "opponent":      opp,
                    "opponent_name": self.names[opp],
                    "your_turn":     uid == self.turn,
                    "symbol":        self.symbols[uid],
                    "state":         self._get_state(),
                })
            except Exception:
                pass

    async def send_state(self, uid: str) -> None:
        """Send current game state to a player who just connected to /ws/room."""
        ws = self.players.get(uid)
        if not ws:
            return
        opp = self._opponent(uid)
        try:
            await ws.send_json({
                "type":          "GAME_STATE",
                "room_id":       self.room_id,
                "opponent":      opp,
                "opponent_name": self.names[opp],
                "your_turn":     uid == self.turn,
                "symbol":        self.symbols[uid],
                "state":         self._get_state(),
                "active":        self.active,
            })
        except Exception:
            pass

    #Move handling

    def validate_move(self, uid: str, move: dict) -> tuple[bool, str]:
        if not self.active:
            return False, "Game is already over."
        if uid != self.turn:
            return False, "It is not your turn."
        cell = move.get("cell")
        if cell is None or not isinstance(cell, int) or not (0 <= cell <= 8):
            return False, "Invalid cell index (must be 0–8)."
        if self.board[cell] is not None:
            return False, "That cell is already occupied."
        return True, ""

    def apply_move(self, uid: str, move: dict) -> str | None:
        """
        Place the piece, advance the turn, check for win / draw.
        Returns:
          - winner uid  if that player just won
          - "DRAW"      if the board is full with no winner
          - None        if the game continues
        """
        cell = move["cell"]
        self.board[cell] = uid
        self.move_history.append({"uid": uid, "cell": cell})

        # Check win
        for line in WIN_LINES:
            if all(self.board[i] == uid for i in line):
                return uid

        # Check draw
        if all(sq is not None for sq in self.board):
            return "DRAW"

        # Game continues — advance turn
        self.turn = self._opponent(uid)
        return None

    #Game end

    async def end(
        self,
        winner_uid: str | None,
        reason: str = "NORMAL",
        elo_deltas: dict | None = None,
    ) -> None:
        if not self.active:
            return
        self.active = False
        loser_uid = self._opponent(winner_uid) if winner_uid and winner_uid != "DRAW" else None

        deltas = elo_deltas or {"winner_delta": 0, "loser_delta": 0}

        for uid, ws in self.players.items():
            try:
                if reason == "DRAW":
                    your_delta = deltas["winner_delta"] if uid == self.player_list[0] else deltas["loser_delta"]
                else:
                    your_delta = deltas["winner_delta"] if uid == winner_uid else deltas["loser_delta"]

                await ws.send_json({
                    "type":         "GAME_OVER",
                    "winner":       winner_uid,
                    "loser":        loser_uid,
                    "reason":       reason,
                    "winner_delta": deltas["winner_delta"],
                    "loser_delta":  deltas["loser_delta"],
                    "your_delta":   your_delta,
                })
            except Exception:
                pass

    #Disconnect / forfeit

    async def handle_disconnect(self, uid: str) -> None:
        """
        Immediately notify the surviving opponent that a player disconnected,
        then start a forfeit grace timer. The timer does NOT call end()/
        remove_room() directly — the router's _delayed_record handles that
        to avoid race conditions with ELO recording.
        """
        await self.notify_opponent_disconnect(uid)

        async def _forfeit():
            await asyncio.sleep(FORFEIT_GRACE_SECONDS)

        task = asyncio.create_task(_forfeit())
        self._forfeit_tasks[uid] = task

    async def notify_opponent_disconnect(self, disconnected_uid: str) -> None:
        """Send an immediate OPPONENT_DISCONNECTED message to the surviving player."""
        opp_uid = self._opponent(disconnected_uid)
        ws = self.players.get(opp_uid)
        if ws:
            try:
                await ws.send_json({
                    "type":           "OPPONENT_DISCONNECTED",
                    "disconnected":   disconnected_uid,
                    "grace_seconds":  FORFEIT_GRACE_SECONDS,
                })
            except Exception:
                pass

    async def notify_opponent_reconnect(self, reconnected_uid: str) -> None:
        """Send OPPONENT_RECONNECTED when the disconnected player comes back."""
        opp_uid = self._opponent(reconnected_uid)
        ws = self.players.get(opp_uid)
        if ws:
            try:
                await ws.send_json({
                    "type":        "OPPONENT_RECONNECTED",
                    "reconnected": reconnected_uid,
                })
            except Exception:
                pass

    def cancel_forfeit_timer(self, uid: str) -> None:
        task = self._forfeit_tasks.pop(uid, None)
        if task:
            task.cancel()

    #Broadcast helpers

    async def broadcast(self, message: dict, exclude: str | None = None) -> None:
        for uid, ws in self.players.items():
            if uid != exclude:
                try:
                    await ws.send_json(message)
                except Exception:
                    pass

    #Internal

    def _opponent(self, uid: str) -> str:
        return self.player_list[1] if uid == self.player_list[0] else self.player_list[0]


#Room registry

_rooms: dict[str, GameRoom] = {}


def create_room(
    uid_a: str, name_a: str,
    uid_b: str, name_b: str,
    ws_a: WebSocket, ws_b: WebSocket,
) -> GameRoom:
    room_id = str(uuid.uuid4())
    room    = GameRoom(room_id, uid_a, name_a, uid_b, name_b, ws_a, ws_b)
    _rooms[room_id] = room
    return room


def get_room(room_id: str) -> GameRoom | None:
    return _rooms.get(room_id)


def remove_room(room_id: str) -> None:
    _rooms.pop(room_id, None)
