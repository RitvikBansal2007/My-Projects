from fastapi import WebSocket


class LobbyManager:
    """
    Global presence lobby.
    _connections: { uid → {"ws": WebSocket, "name": str} }
    _challenges:  { challenger_uid → target_uid }
    """

    def __init__(self):
        self._connections: dict[str, dict]  = {}
        self._challenges:  dict[str, str]   = {}

    #Connection lifecycle

    async def connect(self, uid: str, name: str, ws: WebSocket) -> None:
        await ws.accept()
        self._connections[uid] = {"ws": ws, "name": name}

        await self._broadcast(
            {"type": "PLAYER_JOINED", "uid": uid, "name": name},
            exclude=uid,
        )

        await ws.send_json({
            "type": "LOBBY_STATE",
            "players": [
                {"uid": u, "name": data["name"]}
                for u, data in self._connections.items()
                if u != uid
            ],
        })

    async def disconnect(self, uid: str) -> None:
        self._connections.pop(uid, None)
        self._challenges = {
            c: t for c, t in self._challenges.items()
            if c != uid and t != uid
        }
        await self._broadcast({"type": "PLAYER_LEFT", "uid": uid})

    #Challenge flow 

    async def send_challenge(self, challenger_uid: str, target_uid: str) -> None:
        if target_uid == challenger_uid:
            ws = self._get_ws(challenger_uid)
            if ws:
                await ws.send_json({"type": "ERROR", "reason": "Cannot challenge yourself."})
            return

        target_data = self._connections.get(target_uid)
        if not target_data:
            ws = self._get_ws(challenger_uid)
            if ws:
                await ws.send_json({"type": "ERROR", "reason": "Player is not in the lobby."})
            return

        challenger_name = self._connections.get(challenger_uid, {}).get("name", challenger_uid)
        self._challenges[challenger_uid] = target_uid

        await target_data["ws"].send_json({
            "type":      "CHALLENGE_RECEIVED",
            "from":      challenger_uid,
            "from_name": challenger_name, 
        })

    async def decline_challenge(self, decliner_uid: str, challenger_uid: str) -> None:
        """Called when the challenged player presses Decline (or timer expires)."""
        if self._challenges.get(challenger_uid) == decliner_uid:
            del self._challenges[challenger_uid]

        decliner_name = self._connections.get(decliner_uid, {}).get("name", decliner_uid)
        ws = self._get_ws(challenger_uid)
        if ws:
            await ws.send_json({
                "type":   "CHALLENGE_DECLINED",
                "reason": f"{decliner_name} declined your challenge.",
            })

    async def cancel_challenge(self, challenger_uid: str, target_uid: str) -> None:
        """Called when the challenger presses Cancel while waiting."""
        self._challenges.pop(challenger_uid, None)
        ws = self._get_ws(target_uid)
        if ws:
            await ws.send_json({
                "type": "CHALLENGE_CANCELLED",
                "from": challenger_uid,
            })

    async def accept_challenge(
        self, acceptor_uid: str, challenger_uid: str
    ) -> tuple[str, str] | None:
        if self._challenges.get(challenger_uid) == acceptor_uid:
            del self._challenges[challenger_uid]
            return challenger_uid, acceptor_uid
        return None

    #Room migration

    def pop_player(self, uid: str) -> tuple:
        """Remove a player from the lobby; return (ws, name) for room creation."""
        data = self._connections.pop(uid, None)
        if data:
            return data["ws"], data["name"]
        return None, None

    #Internal helpers

    def _get_ws(self, uid: str) -> WebSocket | None:
        data = self._connections.get(uid)
        return data["ws"] if data else None

    async def _broadcast(self, message: dict, exclude: str | None = None) -> None:
        dead: list[str] = []
        for uid, data in list(self._connections.items()):
            if uid == exclude:
                continue
            try:
                await data["ws"].send_json(message)
            except Exception:
                dead.append(uid)
        for uid in dead:
            self._connections.pop(uid, None)


lobby_manager = LobbyManager()
