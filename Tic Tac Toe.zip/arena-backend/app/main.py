from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.database.mysql import engine
from app.database.models import Base
from app.database.mongo import close_mongo
from app.phase2_auth.router import auth_router
from app.phase3_arena.router import arena_router
from app.phase4_elo.router import elo_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await close_mongo()


app = FastAPI(title="ARENA Backend", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# /api/auth/face-login  etc.
app.include_router(auth_router, prefix="/api")

# /ws/lobby   /ws/room/{room_id}
app.include_router(arena_router)

# /leaderboard/
app.include_router(elo_router)

# Serve frontend/
app.mount("/static", StaticFiles(directory="frontend"), name="static")
