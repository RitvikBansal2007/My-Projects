from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    mysql_host:     str = "127.0.0.1"
    mysql_port:     int = 3306
    mysql_user:     str = "arena_user"
    mysql_password: str = "Arena1234!"
    mysql_db:       str = "arena_db"

    mongo_uri: str = "mongodb://localhost:27017"
    mongo_db:  str = "arena_db"

    session_secret_key:  str = "bf02a42581aba16066112166e11b0b7eab9cb3a5d64db354f613125ec6b6616e"
    session_ttl_seconds: int = 3600

    debug: bool = True

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()