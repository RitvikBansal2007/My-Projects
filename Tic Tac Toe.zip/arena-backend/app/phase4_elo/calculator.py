
K: int = 32 


def expected_score(rating_a: int, rating_b: int) -> float:
    """Expected score for Player A facing Player B."""
    return 1.0 / (1.0 + 10 ** ((rating_b - rating_a) / 400.0))


def calculate_new_ratings(winner_rating: int, loser_rating: int) -> tuple[int, int]:
    """
    Returns (winner_new_rating, loser_new_rating).
    K=32, Score_winner=1.0, Score_loser=0.0.
    """
    e_win  = expected_score(winner_rating, loser_rating)
    e_lose = expected_score(loser_rating, winner_rating)
    return (
        round(winner_rating + K * (1.0 - e_win)),
        round(loser_rating  + K * (0.0 - e_lose)),
    )


def elo_delta(winner_rating: int, loser_rating: int) -> tuple[int, int]:
    """
    Returns (winner_delta, loser_delta) as signed ints.
    winner_delta > 0, loser_delta < 0.
    """
    w_new, l_new = calculate_new_ratings(winner_rating, loser_rating)
    return (w_new - winner_rating), (l_new - loser_rating)


def draw_elo_delta(rating_a: int, rating_b: int) -> tuple[int, int]:
    """
    Returns (delta_a, delta_b) for a draw (S=0.5 for both players).
    If both players have equal ratings, both deltas will be 0.
    """
    e_a = expected_score(rating_a, rating_b)
    e_b = expected_score(rating_b, rating_a)
    delta_a = round(K * (0.5 - e_a))
    delta_b = round(K * (0.5 - e_b))
    return delta_a, delta_b