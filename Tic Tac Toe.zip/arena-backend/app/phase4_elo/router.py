from fastapi import APIRouter, Depends
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.mysql  import get_db
from app.database.models import Player, MatchHistory
from app.phase4_elo.calculator import elo_delta, draw_elo_delta

elo_router = APIRouter(prefix="/leaderboard", tags=["leaderboard"])


@elo_router.get("/")
async def leaderboard(
    limit:  int = 0,
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
):
    """Global leaderboard sorted by Elo rating descending.
    Default limit=0 means all players (as required by the project spec)."""
    query = (
        select(Player.id, Player.name, Player.elo_rating)
        .order_by(Player.elo_rating.desc())
        .offset(offset)
    )
    if limit > 0:
        query = query.limit(limit)
    result = await db.execute(query)
    return [
        {"rank": offset + i + 1, "uid": r.id, "name": r.name, "elo": r.elo_rating}
        for i, r in enumerate(result.fetchall())
    ]


async def record_match_result(
    winner_uid: str,
    loser_uid:  str,
    forfeit:    bool,
    room_id:    str,
    db:         AsyncSession,
) -> dict:
    """
    Fetch current ratings → compute Elo deltas → UPDATE both players →
    INSERT match_history row.  Called by the arena router after every game end.
    Returns { winner_delta, loser_delta } for use in GAME_OVER messages.
    """
    winner = await db.get(Player, winner_uid)
    loser  = await db.get(Player, loser_uid)

    if not winner or not loser:
        return {"winner_delta": 0, "loser_delta": 0}

    w_delta, l_delta = elo_delta(winner.elo_rating, loser.elo_rating)

    await db.execute(
        update(Player)
        .where(Player.id == winner_uid)
        .values(elo_rating=Player.elo_rating + w_delta)
    )
    await db.execute(
        update(Player)
        .where(Player.id == loser_uid)
        .values(elo_rating=Player.elo_rating + l_delta)
    )
    db.add(MatchHistory(
        room_id=room_id, winner_id=winner_uid, loser_id=loser_uid,
        winner_delta=w_delta, loser_delta=l_delta, forfeit=forfeit,
    ))
    await db.commit()
    return {"winner_delta": w_delta, "loser_delta": l_delta}


async def record_draw_result(
    uid_a:   str,
    uid_b:   str,
    room_id: str,
    db:      AsyncSession,
) -> dict:
    """
    Handle a draw outcome: compute S=0.5 Elo deltas for both players,
    update their ratings, and insert a match_history row with draw=True.
    Returns { delta_a, delta_b } for use in GAME_OVER messages.
    """
    player_a = await db.get(Player, uid_a)
    player_b = await db.get(Player, uid_b)

    if not player_a or not player_b:
        return {"delta_a": 0, "delta_b": 0}

    delta_a, delta_b = draw_elo_delta(player_a.elo_rating, player_b.elo_rating)

    await db.execute(
        update(Player)
        .where(Player.id == uid_a)
        .values(elo_rating=Player.elo_rating + delta_a)
    )
    await db.execute(
        update(Player)
        .where(Player.id == uid_b)
        .values(elo_rating=Player.elo_rating + delta_b)
    )
    db.add(MatchHistory(
        room_id=room_id,
        winner_id=None,
        loser_id=None,
        winner_delta=delta_a,
        loser_delta=delta_b,
        draw=True,
    ))
    await db.commit()
    return {"delta_a": delta_a, "delta_b": delta_b}
