from datetime import datetime
from sqlalchemy import String, Integer, Boolean, DateTime, Text, ForeignKey, BigInteger, SmallInteger
from sqlalchemy.orm import Mapped, mapped_column
from app.database.mysql import Base

class Player(Base):
    __tablename__ = "players"
    id:             Mapped[str]           = mapped_column(String(20),  primary_key=True)
    name:           Mapped[str]           = mapped_column(String(200), nullable=False)
    elo_rating:     Mapped[int]           = mapped_column(Integer,     default=1200, nullable=False)
    is_online:      Mapped[bool]          = mapped_column(Boolean,     default=False, nullable=False)
    mongo_image_id: Mapped[str]           = mapped_column(String(24),  nullable=False)
    website_url:    Mapped[str | None]    = mapped_column(String(300))
    created_at:     Mapped[datetime]      = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:     Mapped[datetime]      = mapped_column(DateTime, default=datetime.utcnow,
                                                            onupdate=datetime.utcnow)

class MatchHistory(Base):
    __tablename__ = "match_history"
    id:           Mapped[int]      = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    room_id:      Mapped[str]      = mapped_column(String(36), nullable=False)
    winner_id:    Mapped[str | None] = mapped_column(String(20), ForeignKey("players.id"), nullable=True)
    loser_id:     Mapped[str | None] = mapped_column(String(20), ForeignKey("players.id"), nullable=True)
    winner_delta: Mapped[int]      = mapped_column(Integer, nullable=False)
    loser_delta:  Mapped[int]      = mapped_column(Integer, nullable=False)
    forfeit:      Mapped[bool]     = mapped_column(Boolean, default=False)
    draw:         Mapped[bool]     = mapped_column(Boolean, default=False)
    played_at:    Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class HarvestError(Base):
    __tablename__ = "harvest_errors"
    id:            Mapped[int]          = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    source_row:    Mapped[int | None]   = mapped_column(Integer)
    uid:           Mapped[str | None]   = mapped_column(String(20))
    website_url:   Mapped[str | None]   = mapped_column(String(300))
    error_message: Mapped[str | None]   = mapped_column(Text)
    occurred_at:   Mapped[datetime]     = mapped_column(DateTime, default=datetime.utcnow)