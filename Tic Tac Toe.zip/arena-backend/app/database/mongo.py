from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorCollection
from app.config import settings

_client: AsyncIOMotorClient | None = None

def get_mongo_client() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(settings.mongo_uri)
    return _client

def get_images_collection() -> AsyncIOMotorCollection:
    """Returns the player_images collection."""
    return get_mongo_client()[settings.mongo_db]["player_images"]

async def close_mongo() -> None:
    global _client
    if _client:
        _client.close()
        _client = None