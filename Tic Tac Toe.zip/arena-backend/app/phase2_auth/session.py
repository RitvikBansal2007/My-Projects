import time
import secrets
from itsdangerous import TimestampSigner, BadSignature, SignatureExpired
from app.config import settings

_signer = TimestampSigner(settings.session_secret_key)
_sessions: dict[str, dict] = {}


def create_session(uid: str, name: str) -> str:
    """Create and store a new signed session. Returns the signed token string."""
    raw   = secrets.token_hex(32)
    signed = _signer.sign(raw).decode()
    _sessions[raw] = {
        "uid":        uid,
        "name":       name,
        "expires_at": time.time() + settings.session_ttl_seconds,
    }
    return signed


def validate_session(signed_token: str) -> dict | None:
    """Returns session data dict or None if invalid/expired."""
    try:
        raw  = _signer.unsign(signed_token, max_age=settings.session_ttl_seconds).decode()
        data = _sessions.get(raw)
        if data and time.time() < data["expires_at"]:
            return data
    except (BadSignature, SignatureExpired):
        pass
    return None


def destroy_session(signed_token: str) -> bool:
    try:
        raw = _signer.unsign(signed_token, max_age=settings.session_ttl_seconds).decode()
        return _sessions.pop(raw, None) is not None
    except (BadSignature, SignatureExpired):
        return False