from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy import select, func, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.mysql import get_db
from app.database.models import Player
from app.database.mongo import get_images_collection
from app.phase2_auth.session import create_session
from app.phase2_auth.facial_recognition_module import find_closest_match, build_encodings_cache

auth_router = APIRouter(prefix="/auth", tags=["auth"])

ENCODINGS_CACHE = {}


class FaceLoginRequest(BaseModel):
    image: str    
    username: str  


@auth_router.post("/face-login")
async def face_login(body: FaceLoginRequest, db: AsyncSession = Depends(get_db)):
    global ENCODINGS_CACHE

    #Look up the player record by name
    clean_name = body.username.strip().lower()
    query  = select(Player).where(func.lower(func.trim(Player.name)) == clean_name)
    result = await db.execute(query)
    player = result.scalar_one_or_none()

    if not player:
        raise HTTPException(status_code=404, detail="Callsign not found in Arena records.")

    #Build / reuse the biometric encoding cache
    if not ENCODINGS_CACHE:
        col = get_images_collection()
        db_images_dict: dict[str, bytes] = {}
        async for doc in col.find({}, {"uid": 1, "image_data": 1}):
            if doc.get("uid") and doc.get("image_data"):
                db_images_dict[str(doc["uid"])] = doc["image_data"]

        if not db_images_dict:
            raise HTTPException(status_code=503, detail="Biometric database is empty.")

        ENCODINGS_CACHE = build_encodings_cache(db_images_dict)

    #Identity handshake
    matched_uid = find_closest_match(body.image, ENCODINGS_CACHE)

    if matched_uid != str(player.id):
        raise HTTPException(
            status_code=401,
            detail="Identity Mismatch: Face does not match the provided callsign.",
        )

    #Set is_online = TRUE in MySQL
    await db.execute(
        update(Player).where(Player.id == player.id).values(is_online=True)
    )
    await db.commit()

    #Issue session token
    token = create_session(player.id, player.name)

    return {
        "token":    token,
        "uid":      str(player.id),   
        "username": player.name,
    }
