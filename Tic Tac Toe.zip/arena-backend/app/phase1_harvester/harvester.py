"""
FILE: app/phase1_harvester/harvester.py
Phase 1 — Polyglot Harvester

Real CSV schema  →  uid, name, website_url
                    (no email, no direct image_url)

Pipeline per row:
  1. Build full profile URL  →  https://<website_url>
  2. [PRIMARY]  Try direct image URL  →  <profile_url>/images/pfp.jpg
  3. [FALLBACK] If 404 / not an image: fetch HTML, scrape <img> tag
  4. Download image bytes
  5. Write raw bytes to MongoDB  →  player_images collection
  6. Write uid + name + mongo_image_id to MySQL  →  players table
  On any failure → write to harvest_errors table, continue

Key for facial_recognition_module:
  - MongoDB documents store raw bytes under key "image_data"
  - MongoDB document key "uid" = the uid string from the CSV
  - find_closest_match() receives { uid: raw_bytes } dict
    and returns the uid string — so uid must match exactly.

Run:
  uv run python -m app.phase1_harvester.harvester \\
      --csv data/batch_data.csv --concurrency 8
"""

import asyncio
import logging
import argparse
from datetime import datetime
from urllib.parse import urljoin, urlparse

import httpx
import pandas as pd
from bs4 import BeautifulSoup
from tenacity import retry, wait_exponential, stop_after_attempt, RetryError

from app.database.mysql import AsyncSessionLocal
from app.database.mongo import get_images_collection
from app.database.models import Player, HarvestError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger(__name__)

def build_profile_url(raw_url: str) -> str:
    """
    The CSV stores partial URLs like 'web.iiit.ac.in/~firstname.lastname'.
    Prepend https:// if missing.
    """
    raw_url = raw_url.strip()
    if not raw_url.startswith(("http://", "https://")):
        return "https://" + raw_url
    return raw_url


def build_direct_image_url(profile_url: str) -> str:
    """
    Construct the known-location image URL by appending /images/pfp.jpg
    to the profile page URL.

    Example:
        https://web.iiit.ac.in/~player.name  →
        https://web.iiit.ac.in/~player.name/images/pfp.jpg
    """
    return profile_url.rstrip("/") + "/images/pfp.jpg"


def make_absolute(img_src: str, base_url: str) -> str:
    """Convert a relative img src to an absolute URL."""
    if img_src.startswith(("http://", "https://")):
        return img_src
    return urljoin(base_url, img_src)


# ── Profile photo extraction (FALLBACK scraper) ───────────────────────────────

_SKIP_KEYWORDS = {"logo", "icon", "banner", "badge", "sprite", "button",
                  "bg", "background", "footer", "header", "nav"}

def _is_skip_src(src: str) -> bool:
    low = src.lower()
    return any(kw in low for kw in _SKIP_KEYWORDS)


def find_profile_image_url(html: str, profile_url: str, username_hint: str) -> str | None:
    """
    FALLBACK: Parse the IIIT profile page HTML and return the absolute URL
    of the most likely profile photo.

    Only called when the direct /images/pfp.jpg path fails (404 / non-image).

    Strategy (tried in order):
      1. <img> whose src contains the username hint (e.g. "~player.name")
      2. <img> with class/id containing "photo", "profile", or "avatar"
      3. First non-trivial <img> inside <main>, <article>, or .content/.main
      4. First non-trivial <img> anywhere on the page
    """
    soup = BeautifulSoup(html, "lxml")
    def to_abs(tag) -> str | None:
        src = tag.get("src") or tag.get("data-src", "")
        if not src or _is_skip_src(src):
            return None
        return make_absolute(src, profile_url)

    # Strategy 1: username-based match
    hint = username_hint.lstrip("~").lower()
    for img in soup.find_all("img"):
        src = (img.get("src") or "").lower()
        if hint in src:
            url = to_abs(img)
            if url:
                return url

    # Strategy 2: semantic class/id match
    profile_keywords = {"photo", "profile", "avatar", "headshot", "picture"}
    for img in soup.find_all("img"):
        classes = " ".join(img.get("class", [])).lower()
        img_id  = (img.get("id") or "").lower()
        if any(kw in classes or kw in img_id for kw in profile_keywords):
            url = to_abs(img)
            if url:
                return url

    # Strategy 3: first image inside main content container
    for container_selector in ["main", "article", '[class*="content"]', '[class*="main"]']:
        container = soup.select_one(container_selector)
        if container:
            for img in container.find_all("img"):
                url = to_abs(img)
                if url:
                    return url

    # Strategy 4: first non-skip image on the page
    for img in soup.find_all("img"):
        url = to_abs(img)
        if url:
            return url

    return None

@retry(
    wait=wait_exponential(multiplier=1, min=2, max=15),
    stop=stop_after_attempt(3),
    reraise=True,
)
async def _fetch_page(client: httpx.AsyncClient, url: str) -> str:
    """Fetch a profile page and return its HTML text."""
    resp = await client.get(url, timeout=20.0, follow_redirects=True)
    resp.raise_for_status()
    return resp.text


@retry(
    wait=wait_exponential(multiplier=1, min=2, max=15),
    stop=stop_after_attempt(3),
    reraise=True,
)
async def _download_image(client: httpx.AsyncClient, url: str) -> bytes:
    """Download raw image bytes."""
    resp = await client.get(url, timeout=20.0, follow_redirects=True)
    resp.raise_for_status()
    content_type = resp.headers.get("content-type", "")
    if "image" not in content_type and not url.lower().endswith(
        (".jpg", ".jpeg", ".png", ".gif", ".webp")
    ):
        raise ValueError(f"Response is not an image (Content-Type: {content_type})")
    return resp.content


async def _try_download_image_no_retry(client: httpx.AsyncClient, url: str) -> bytes | None:
    """
    Single-attempt image download used for the direct /images/pfp.jpg probe.
    Returns None on any error so the caller can fall through to the scraper.
    No retry — if the known path 404s, we want to fall back immediately.
    """
    try:
        resp = await client.get(url, timeout=10.0, follow_redirects=True)
        if resp.status_code != 200:
            return None
        content_type = resp.headers.get("content-type", "")
        if "image" not in content_type and not url.lower().endswith(
            (".jpg", ".jpeg", ".png", ".gif", ".webp")
        ):
            return None
        return resp.content
    except Exception:
        return None


def _detect_mime(image_bytes: bytes) -> str:
    if image_bytes[:4] == b"\x89PNG":
        return "image/png"
    if image_bytes[:2] == b"\xff\xd8":
        return "image/jpeg"
    return "application/octet-stream"


# ── Per-row harvesting logic ──────────────────────────────────────────────────

async def _harvest_one_row(
    row_index: int,
    uid: str,
    name: str,
    website_url_raw: str,
    client: httpx.AsyncClient,
) -> None:
    """
      Image acquisition order:
      PRIMARY  — GET <profile_url>/images/pfp.jpg directly (no HTML fetch needed)
      FALLBACK — Fetch profile HTML, scrape for best <img> candidate
    """
    async with AsyncSessionLocal() as db:
        try:
            profile_url = build_profile_url(website_url_raw)

            direct_img_url = build_direct_image_url(profile_url)
            log.info(
                f"[Row {row_index}] uid={uid} | "
                f"Trying direct image URL: {direct_img_url}"
            )
            image_bytes = await _try_download_image_no_retry(client, direct_img_url)

            if not image_bytes:
                raise ValueError(f"Profile image not found at {direct_img_url}")

            img_url = direct_img_url
            log.info(
                f"[Row {row_index}] uid={uid} | "
                f"Direct /images/pfp.jpg succeeded ({len(image_bytes)} bytes)"
            )

            mime_type = _detect_mime(image_bytes)
            log.info(
                f"[Row {row_index}] uid={uid} | "
                f"Downloaded {len(image_bytes)} bytes ({mime_type}) from {img_url}"
            )
            col = get_images_collection()
            mongo_doc = {
                "uid":        uid,            
                "image_data": image_bytes,    
                "mime_type":  mime_type,
                "source_url": img_url,     
                "created_at": datetime.utcnow(),
            }
            mongo_result = await col.insert_one(mongo_doc)
            mongo_image_id = str(mongo_result.inserted_id)
            log.info(f"[Row {row_index}] uid={uid} | MongoDB _id={mongo_image_id}")

            async with db.begin():
                existing = await db.get(Player, uid)
                if existing:
                    log.warning(
                        f"[Row {row_index}] uid={uid} already in MySQL — skipping."
                    )
                    return

                db.add(Player(
                    id=uid,
                    name=name,
                    elo_rating=1200,
                    mongo_image_id=mongo_image_id,
                    website_url=website_url_raw,
                ))
            log.info(f"[Row {row_index}] uid={uid} | MySQL insert OK")

        except Exception as exc:
            log.error(f"[Row {row_index}] uid={uid} FAILED: {exc}")
            try:
                async with db.begin():
                    db.add(HarvestError(
                        source_row=row_index,
                        uid=uid or None,
                        website_url=website_url_raw or None,
                        error_message=str(exc)[:2000],
                    ))
            except Exception as log_exc:
                log.critical(
                    f"[Row {row_index}] Failed to write harvest_error: {log_exc}"
                )

async def run_harvester(csv_path: str, concurrency: int = 8) -> None:
    log.info(f"Loading CSV: {csv_path}")
    df = pd.read_csv(csv_path, dtype=str) 

    required = {"uid", "name", "website_url"}
    missing  = required - set(df.columns)
    if missing:
        raise ValueError(
            f"CSV is missing required columns: {missing}. "
            f"Found columns: {list(df.columns)}"
        )

    rows  = df.to_dict(orient="records")
    total = len(rows)
    log.info(f"Total rows to process: {total} | Concurrency: {concurrency}")

    semaphore = asyncio.Semaphore(concurrency)

    async def _bounded(i: int, row: dict):
        async with semaphore:
            uid         = str(row.get("uid", "")).strip()
            name        = str(row.get("name", "")).strip()
            website_url = str(row.get("website_url", "")).strip()
            await _harvest_one_row(i, uid, name, website_url, client)

    async with httpx.AsyncClient(
        http2=True,
        headers={"User-Agent": "Mozilla/5.0 ArenaHarvester/3.0"},
    ) as client:
        tasks = [_bounded(i, row) for i, row in enumerate(rows)]
        await asyncio.gather(*tasks)

    log.info("Harvester run complete.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Phase 1 — Polyglot Harvester")
    parser.add_argument(
        "--csv",
        required=True,
        help="Path to batch_data.csv (columns: uid, name, website_url)",
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=8,
        help="Max concurrent scrape+download tasks (default: 8). "
             "Reduce to 4 if IIIT servers start rate-limiting.",
    )
    args = parser.parse_args()
    asyncio.run(run_harvester(args.csv, args.concurrency))
