#ifndef CONTINUATION_H
#define CONTINUATION_H
void redcontinuation();
void blackcontinuation();
#endif