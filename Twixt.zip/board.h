#ifndef BOARD_H
#define BOARD_H
struct node {
    int r,c;
    struct node *next;
};
struct item
{
    char e[100];
    int player;
    // 0 = Empty, 1 = Red, 2 = Black;
    struct node *head;
};
extern struct item board[24][24];
extern char green[];
extern char red[];
extern char black[]; 
void iboard();
#endif