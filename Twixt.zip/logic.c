#include "logic.h"
#include "board.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int on(int p_r,int p_c,int q_r,int q_c,int r_r,int r_c) 
{ 
    if (q_c <= (p_c > r_c ? p_c : r_c) && q_c >= (p_c < r_c ? p_c : r_c) && q_r <= (p_r > r_r ? p_r : r_r) && q_r >= (p_r < r_r ? p_r : r_r)) 
    return 1; 
    return 0; 
} 
void add(int r1,int c1,int r2,int c2)
{
    struct node* newnode=(struct node*)malloc(sizeof(struct node));
    newnode->r=r2;
    newnode->c=c2;
    newnode->next=board[r1][c1].head;
    board[r1][c1].head=newnode;
    struct node* newnode2=(struct node*)malloc(sizeof(struct node));
    newnode2->r=r1;
    newnode2->c=c1;
    newnode2->next=board[r2][c2].head;
    board[r2][c2].head=newnode2;
}
int orri(int p_r,int p_c,int q_r,int q_c,int r_r,int r_c)
{
    int val=(q_c-p_c)*(r_r-q_r)-(q_r-p_r)*(r_c-q_c); 
    if(val==0) return 0;
    return (val > 0)? 1: 2;
}
int seg(int p1_r,int p1_c,int q1_r,int q1_c,int p2_r,int p2_c,int q2_r,int q2_c)
{
    if((p1_r==p2_r && p1_c==p2_c)||(p1_r==q2_r && p1_c==q2_c)||(q1_r==p2_r && q1_c==p2_c)||(q1_r==q2_r && q1_c==q2_c))
        return 0;
    int o1=orri(p1_r,p1_c,q1_r,q1_c,p2_r,p2_c); 
    int o2=orri(p1_r,p1_c,q1_r,q1_c,q2_r,q2_c); 
    int o3=orri(p2_r,p2_c,q2_r,q2_c,p1_r,p1_c); 
    int o4=orri(p2_r,p2_c,q2_r,q2_c,q1_r,q1_c); 
    if(o1!=o2 && o3!=o4) return 1; 
    if(o1==0 && on(p1_r,p1_c,p2_r,p2_c,q1_r,q1_c)) return 1; 
    if(o2==0 && on(p1_r,p1_c,q2_r,q2_c,q1_r,q1_c)) return 1; 
    if(o3==0 && on(p2_r,p2_c,p1_r,p1_c,q2_r,q2_c)) return 1; 
    if(o4==0 && on(p2_r,p2_c,q1_r,q1_c,q2_r,q2_c)) return 1; 
    return 0;
}
int linkb(int r1,int c1,int r2,int c2)
{
    for(int i=1;i<=22;i++)
    {
        for(int j=1;j<=22;j++)
        {
            struct node* curr=board[i][j].head;
            while(curr!=NULL) 
            {
                if(seg(r1,c1,r2,c2,i,j,curr->r,curr->c))
                return 1;
                curr=curr->next;
            }
        }
    }
    return 0;
}
int vplace(int r,int c,int player)
{
    if(r > 22 || r < 1 || c > 22 || c < 1 || (board[r][c].player != 0)) return 0;
    board[r][c].player=player;
    return 1;
}

int placelink(int r,int c,int player)
{
    if(!vplace(r,c,player)) return 0;
    int sr[]={-2,-2,-1,-1,1,1,2,2};
    int sc[]={-1,1,-2,2,-2,2,-1,1};
    int count=0;
    for(int i=0;i<8;i++)
    {
        int nr=r+sr[i];
        int nc=c+sc[i];
        if(nr>=1 && nr<=22 && nc>=1 && nc<=22)
        {
            if(board[nr][nc].player==player)
            {
                if(!linkb(r,c,nr,nc))
                {
                    add(r,c,nr,nc);
                    count++;
                }
                else
                {
                    printf("Link to (%d,%d) blocked by barrier! 🥲\n",nc,nr);
                }
            }
        }
    }
    if(count>0) printf("Created %d links\n",count);
    else
    {
        board[r][c].player=0;
        return 0;
    }
    return 1;
}
int vis[24][24];
int mnop(int r,int c,int t,int ver)
{
    vis[r][c]=1;
    if(ver && r >= 22) return 1;
    if(!ver && c >= 22) return 1;
    
    struct node* curr=board[r][c].head;
    while(curr!=NULL)
    {
        if(!vis[curr->r][curr->c])
        {
            if(mnop(curr->r,curr->c,t,ver)) return 1;
        }
        curr=curr->next;
    }
    return 0;
}
int rwin()
{
    memset(vis,0,sizeof(vis));
    for(int j=1;j<=22;j++)
    {
        if(board[1][j].player == 1)
        {
            if(mnop(1,j,22,1)) return 1;
        }
    }
    return 0;
}
int bwin()
{
    memset(vis,0,sizeof(vis));
    for(int i=1;i<=22;i++)
    {
        if(board[i][1].player == 2)
        {
            if(mnop(i,1,22,0)) return 1;
        }
    }
    return 0;
}