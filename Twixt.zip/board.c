#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "board.h"
struct item board[24][24];
char green[]="🟢";
char red[]="🔴";
char black[]="⚫️";
void iboard()
{
    for(int i=0;i<24;i++)
    {
        for(int j=0;j<24;j++)
        {
            strcpy(board[i][j].e,green);
            board[i][j].player=0;
            board[i][j].head=NULL;
        }
    }
}