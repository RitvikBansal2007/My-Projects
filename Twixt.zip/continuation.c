#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"logic.h"
#include"board.h"
#include"mainfile.h"

void printboard()
{
    for(int i=0;i<24;i++)
    {
        for(int j=0;j<24;j++)
        {
            printf("%s  ",board[i][j].e);
        }
        printf("\n\n");
    }
}
void blackcontinuation();
void redcontinuation()
{
    printf("\n\033[1;31mRed's Turn ❤️\n\n");
    char str[30];
    scanf("%s",str);
    char place[]="Place";
    char link[]="Link";
    char quit[]="Quit";
    char restart[]="Restart";

    if(strcmp(str,place)==0)
    {
        int k,n;
        scanf("%d %d",&n,&k);
        if(vplace(k,n,1))
        {
            printf("Pin Placed 😁\n\n");
            strcpy(board[k][n].e,red);
            printboard();
            blackcontinuation();
        }
        else
        {
            printf("Invalid Move 🤬\n\n");
            redcontinuation();
        }
    }
    else if(strcmp(str,link)==0)
    {
        int k,n;
        scanf("%d %d",&n,&k); 
        if(placelink(k,n,1))
        {
            printf("Pin Placed and Linked 😁\n\n");
            strcpy(board[k][n].e,red);
            if(rwin())
            {
                printf("RED WINS 🥳\n\n");
                mainfile();
            }
            printboard();
            blackcontinuation();
        }
        else 
        {
            printf("Invalid Move 🤬\n\n");
            redcontinuation();
        }
    }
    else if(strcmp(str,quit)==0)
    {
        printf("Game Over 😭\n");
        return;
    }
    else if(strcmp(str,restart)==0)
    {
        printf("Game Restarted 😏\n\n");
        mainfile();
    }
    else
    {
        printf("Invalid Command 🤬\n\n");
        redcontinuation();
    }
}

void blackcontinuation()
{
    printf("\n\033[0mBlack's Turn ♠️\n\n");
    char str[30];
    scanf("%s",str);
    char place[]="Place";
    char link[]="Link";
    char quit[]="Quit";
    char restart[]="Restart";

    if(strcmp(str,place)==0)
    {
        int k,n;
        scanf("%d %d",&n,&k);
        if (vplace(k,n,2))
        {
            printf("Pin Placed 😁\n\n");
            strcpy(board[k][n].e,black);
            printboard();
            redcontinuation();
        }
        else
        {
            printf("Invalid Move 🤬\n\n");
            blackcontinuation();
        }
    }
    else if(strcmp(str,link)==0)
    {
        int k,n;
        scanf("%d %d",&n,&k);
        if(placelink(k,n,2))
        {
            printf("Pin Placed and Linked 😁\n\n");
            strcpy(board[k][n].e,black);
            if(bwin())
            {
                printf("BLACK WINS 🥳\n\n");
                mainfile();
            }
            printboard();
            redcontinuation();
        }
        else
        {
            printf("Invalid Move 🤬\n\n");
            blackcontinuation();
        }
    }
    else if(strcmp(str,quit)==0)
    {
        printf("Game Over 😭\n");
        return;
    }
    else if(strcmp(str,restart)==0)
    {
        printf("Game Restarted 😏\n\n");
        mainfile();
    }
    else
    { 
        printf("Invalid Command 🤬\n\n");
        blackcontinuation();
    }
}