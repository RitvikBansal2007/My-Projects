#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"continuation.h"
#include"board.h"
void mainfile()
{
    iboard();
    printf("\033[1;32mRULES:\n");
    printf("1. Player Red is represented by '🔴' and Black by '⚫️'\n");
    printf("2. any pin can be represented as a b where (a,b) are co-ordinates 1<=a,b<=22 where b increases as we go down and a increases as we move right\n");
    printf("3. To PLACE FIRST PIN ENTER 'Place a b' This command is active throughout game but use this command to place first pin only 🙏🏻 else no links will be stored and it will f*ck the game 😭\n");
    printf("4. To PLACE NEW PIN AND AUTOMATICALLY LINK IT ENTER 'Link a b'\n");
    printf("5. To QUIT GAME ENTER 'Quit'\n");
    printf("6. To RESTART GAME ENTER 'Restart'\n");
    printf("\nGame Begin  3️⃣  2️⃣  1️⃣ ······\033[0m\n\n");
    redcontinuation();
}