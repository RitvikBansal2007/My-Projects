#ifndef LOGIC_H
#define LOGIC_H
int vplace(int r,int c,int player);
int placelink(int r,int c,int player);
int rwin();
int bwin();
#endif