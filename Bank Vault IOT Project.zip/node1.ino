#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <Wire.h>
#include "MAX30105.h" 

// --- WIFI & MQTT CREDENTIALS ---
const char* ssid = "your wifi";
const char* password = "your password";
const char* mqttServer = "Your url";
const int mqttPort = 8883; 
const char* mqttUsername = "vault_admin";
const char* mqttPassword = "12345#@aA#@12345";

// --- PIN DEFINITIONS ---
const int irEntryDetect = 25; // External Hallway IR
const int ledYellow = 26;     // Locked Indicator
const int ledGreen = 27;      // Unlocked Indicator

// --- I2C BUSSES & SENSORS ---
TwoWire I2C_Entry = TwoWire(0); 
TwoWire I2C_Exit = TwoWire(1);  
MAX30105 sensorEntry;
MAX30105 sensorExit;

WiFiClientSecure espClient;
PubSubClient client(espClient);

// --- STATE MACHINE VARIABLES ---
bool isUnlocked = false;
unsigned long unlockTime = 0;
const unsigned long UNLOCK_DURATION = 7000; // 7 seconds
bool isMotionWarningActive = false;

// --- MASTER OCCUPANCY COUNTER ---
int peopleInside = 0; 

// --- CLOUD HEARTBEAT ---
unsigned long lastHeartbeatTime = 0;
const unsigned long HEARTBEAT_INTERVAL = 25000; 

void setup() {
  Serial.begin(115200);
  pinMode(irEntryDetect, INPUT);
  pinMode(ledYellow, OUTPUT);
  pinMode(ledGreen, OUTPUT);

  I2C_Entry.begin(21, 22, 100000); 
  I2C_Exit.begin(32, 33, 100000);  

  Serial.println("Initializing Node 1 Gatekeeper...");

  if (!sensorEntry.begin(I2C_Entry, I2C_SPEED_FAST)) {
    Serial.println("Entry Sensor Error!");
    while(1);
  }
  if (!sensorExit.begin(I2C_Exit, I2C_SPEED_FAST)) {
    Serial.println("Exit Sensor Error!");
    while(1);
  }
  sensorEntry.setup();
  sensorExit.setup();
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println(" Connected!");

  espClient.setInsecure(); 
  client.setServer(mqttServer, mqttPort);
  client.setBufferSize(512); 
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting to HiveMQ...");
    if (client.connect("Node1_Gatekeeper", mqttUsername, mqttPassword)) {
      Serial.println(" Connected!");
      if (!isUnlocked) digitalWrite(ledYellow, HIGH); 
      client.publish("vault/status", "SECURE");
      client.publish("vault/occupancy", String(peopleInside).c_str());
    } else { delay(5000); }
  }
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop(); 

  // --- 1. AUTO-LOCKING TIMER ---
  if (isUnlocked && (millis() - unlockTime >= UNLOCK_DURATION)) {
    Serial.println("LOCKING DOOR...");
    digitalWrite(ledGreen, LOW);
    digitalWrite(ledYellow, HIGH);
    
    client.publish("vault/auth", "LOCKED");
    delay(50);
    client.publish("vault/user", "None");
    delay(50);
    client.publish("vault/status", "SECURE");
    
    isMotionWarningActive = false; 
    isUnlocked = false; 
  }

  // --- 2. SENSOR POLLING ---
  if (!isUnlocked) {
    int presence = digitalRead(irEntryDetect);
    long entryValue = sensorEntry.getIR();
    long exitValue = sensorExit.getIR();

    // EXTERNAL IR LOITERING
    if (presence == LOW && !isMotionWarningActive && peopleInside == 0) {
      Serial.println("ALERT: Loitering detected at gate!");
      isMotionWarningActive = true; 
      client.publish("vault/status", "WARNING: External Motion Detected");
    }

    // BIOMETRIC ENTRY (Calibrated to > 10,000)
    if (entryValue > 10000) {
      Serial.println("AUTHORIZED ENTRY");
      peopleInside++;
      
      digitalWrite(ledYellow, LOW);
      digitalWrite(ledGreen, HIGH);
      
      client.publish("vault/occupancy", String(peopleInside).c_str());
      delay(50);
      client.publish("vault/user", "Authorized (Entering)");
      delay(50);
      client.publish("vault/auth", "UNLOCKED");
      delay(50);
      client.publish("vault/status", "SECURE");
      
      isUnlocked = true;
      isMotionWarningActive = false; 
      unlockTime = millis(); 
      delay(1000); // Debounce to prevent double-scans
    }
    
    // BIOMETRIC EXIT (Calibrated to > 10,000)
    else if (exitValue > 10000) {
      Serial.println("EXIT SENSOR TRIGGERED");
      
      if (peopleInside == 0) {
        // FIXED FLAW: The vault is empty. Do not unlock the door.
        Serial.println("TAMPER ATTEMPT: Phantom Exit blocked.");
        client.publish("vault/status", "WARNING: CHECK HALLWAY - TAMPER ATTEMPT");
        delay(1000); // Debounce to prevent spamming the dashboard
      } 
      else {
        // VALID EXIT: Someone is actually inside. Allow them out.
        Serial.println("AUTHORIZED EXIT");
        peopleInside--;
        
        digitalWrite(ledYellow, LOW);
        digitalWrite(ledGreen, HIGH);
        
        client.publish("vault/status", "SECURE");
        delay(50);
        client.publish("vault/occupancy", String(peopleInside).c_str());
        delay(50);
        client.publish("vault/user", "Authorized (Exiting)");
        delay(50);
        client.publish("vault/auth", "UNLOCKED");
        
        isUnlocked = true;
        isMotionWarningActive = false; 
        unlockTime = millis(); 
        delay(1000); // Debounce to prevent double-scans
      }
    }
  }

  // --- 3. INDEPENDENT HEARTBEAT (ping1) ---
  if (millis() - lastHeartbeatTime >= HEARTBEAT_INTERVAL) {
    client.publish("vault/ping1", "PING");
    lastHeartbeatTime = millis(); 
  }
  
  delay(10); 
}