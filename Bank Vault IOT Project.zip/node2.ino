#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>

// --- WIFI & MQTT CREDENTIALS ---
const char* ssid = "your wifi";
const char* password = "your password";
const char* mqttServer = "your url";
const int mqttPort = 8883; 
const char* mqttUsername = "vault_admin";
const char* mqttPassword = "12345#@aA#@12345";

// --- PIN DEFINITIONS ---
const int ledRed = 14;
const int irSensor = 13;
const int ldrCeiling = 34; // Only using Ceiling LDR

// Ultrasonic 1 (Top/Ceiling)
const int trig1 = 5;  
const int echo1 = 27; 

// Ultrasonic 2 (Side/Wall)
const int trig2 = 18; 
const int echo2 = 19;

WiFiClientSecure espClient;
PubSubClient client(espClient);

// --- STATE MACHINE VARIABLES ---
bool isUnlocked = false;       
bool isBreachActive = false;   
int peopleInside = 0; 

// --- SENSOR BASELINES & THRESHOLDS ---
long baselineDist1 = 0;
long baselineDist2 = 0;

// Hardcoded LDR threshold (Triggers if value drops below 1000)
const int LIGHT_THRESHOLD = 1000;  
const int DIST_TOLERANCE = 10;     

// --- TIMERS & BLINKERS ---
unsigned long lastHeartbeatTime = 0;
const unsigned long HEARTBEAT_INTERVAL = 25000; 
unsigned long lastSensorPoll = 0;
unsigned long lastBlinkTime = 0;
bool ledState = LOW;

long readDistance(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW); delayMicroseconds(2);
  digitalWrite(trigPin, HIGH); delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH, 30000); 
  if (duration == 0) return 999; 
  return duration * 0.034 / 2;
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (int i = 0; i < length; i++) message += (char)payload[i];
  String t = String(topic);
  
  if (t == "vault/auth") {
    if (message == "UNLOCKED") {
      isUnlocked = true;
      isBreachActive = false; 
      digitalWrite(ledRed, LOW);
      Serial.println("Vault UNLOCKED.");
    } 
    else if (message == "LOCKED") {
      isUnlocked = false;
      Serial.println("Vault LOCKED.");
    }
  }

  if (t == "vault/occupancy") {
    peopleInside = message.toInt();
    Serial.print("Occupancy: "); Serial.println(peopleInside);
    if (peopleInside > 0) {
      isBreachActive = false;
      digitalWrite(ledRed, LOW);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(ledRed, OUTPUT);
  pinMode(irSensor, INPUT);
  pinMode(trig1, OUTPUT); pinMode(echo1, INPUT);
  pinMode(trig2, OUTPUT); pinMode(echo2, INPUT);
  
  digitalWrite(ledRed, HIGH); 
  Serial.println("CALIBRATING SONAR GRID... Keep Vault Closed!");
  delay(3000); 
  
  // Only calibrating sonars, LDR uses absolute threshold of 1000
  baselineDist1 = readDistance(trig1, echo1);
  baselineDist2 = readDistance(trig2, echo2);
  
  digitalWrite(ledRed, LOW); 

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println(" WiFi Connected!");

  espClient.setInsecure(); 
  client.setServer(mqttServer, mqttPort);
  client.setCallback(mqttCallback); 
  client.setBufferSize(512); 
}

void reconnect() {
  while (!client.connected()) {
    if (client.connect("Node2_VaultMonitor", mqttUsername, mqttPassword)) {
      client.subscribe("vault/auth");
      client.subscribe("vault/occupancy");
    } else { delay(5000); }
  }
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop(); 

  // --- 1. BLINKER LOGIC ---
  if (isBreachActive) {
    if (millis() - lastBlinkTime >= 150) {
      ledState = !ledState; 
      digitalWrite(ledRed, ledState);
      lastBlinkTime = millis();
    }
  }

  // --- 2. SENSOR POLLING ---
  if (!isUnlocked && !isBreachActive && (millis() - lastSensorPoll > 100)) {
    
    // CEILING LDR: Triggers if value drops below 1000
    int currentLDR = analogRead(ldrCeiling);
    bool tripCeiling = (currentLDR < LIGHT_THRESHOLD);

    // MOTION TRIO: IR + 2 Sonars (Only active if empty)
    bool tripMotion = false;
    if (peopleInside == 0) {
      int currentIR = digitalRead(irSensor);
      long d1 = readDistance(trig1, echo1);
      long d2 = readDistance(trig2, echo2);

      if (currentIR == LOW || 
          abs(d1 - baselineDist1) > DIST_TOLERANCE || 
          abs(d2 - baselineDist2) > DIST_TOLERANCE) {
        tripMotion = true;
      }
    }

    if (tripCeiling || tripMotion) {
      Serial.println("!!! CRITICAL BREACH !!!");
      isBreachActive = true; 
      client.publish("vault/status", "CRITICAL: BREACH IN VAULT INTERIOR");
      client.loop(); 
    }
    lastSensorPoll = millis();
  }

  // --- 3. INDEPENDENT HEARTBEAT (ping2) ---
  if (millis() - lastHeartbeatTime >= HEARTBEAT_INTERVAL) {
    client.publish("vault/ping2", "PING");
    lastHeartbeatTime = millis(); 
  }
}