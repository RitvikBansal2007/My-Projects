#include "mainfile.h"

int main()
{
    mainfile();
    return 0;
}