#ifndef DELETEALBUM_H
#define DELETEALBUM_H
void deletealbum();
#endif