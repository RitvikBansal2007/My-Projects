#include<stdio.h>
#include"mainfile.h"
#include<string.h>

void addsong()
{
    FILE *album123;
    FILE *song123;
    FILE *album1234;
    int ID12;
    char name12[150];
    char artist12[150];
    char album12[150];
    float time12;
    printf("\033[1;31mDisclaimer:Don't Put Space in between Name(Ritvik Bansal to be written as RitvikBansal)\033[1;32m\n");
    printf("Name:");
    scanf("%s",name12);
    printf("Artist:");
    scanf("%s",artist12);
    printf("ID:");
    scanf("%d",&ID12);
    printf("Album:");
    scanf("%s",album12);
    album123=fopen(album12,"a");
    fprintf(album123,"%d %s %s\n",ID12,name12,artist12);
    fclose(album123);
    song123=fopen("song.txt","a");
    fprintf(song123,"%d %s %s %s\n",ID12,name12,artist12,album12);
    fclose(song123);
    album1234=fopen("album.txt","r");
    char album256[150];
    int f=0;
    while (fscanf(album1234,"%s",album256)!=EOF)
    {
        if(strcmp(album256,album12)==0)
        {
            f=1;
            break;
        }
    }
    fclose(album1234);
    album1234=fopen("album.txt","a");
    if(f!=1) fprintf(album1234,"%s\n",album12);
    fclose(album1234);
    printf("Song Added\n\n");
    mainfile();
}