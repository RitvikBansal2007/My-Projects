#ifndef OPENALBUM_H
#define OPENALBUM_H
void openalbum();
#endif