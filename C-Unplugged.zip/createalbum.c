#include<stdio.h>
#include"mainfile.h"
#include<string.h>

void createalbum()
{
    char album0000[150];
    char album11[150];
    FILE*album00000=fopen("album.txt","r");
    printf("\033[1;31mDisclaimer:Don't Put Space in between Name(Ritvik Bansal to be written as RitvikBansal)\033[1;32m\n");
    printf("Album Name:");
    scanf("%s",album0000);
    int f=0;
    while(fscanf(album00000,"%s",album11)!=EOF)
    {
        if(strcmp(album11,album0000)==0)
        {
            f=1;
            break;
        }
    }
    fclose(album00000);
    album00000=fopen("album.txt","a");
    if(f!=1) fprintf(album00000,"%s\n",album0000);
    fclose(album00000);
    FILE*album11111=fopen(album0000,"a");
    fclose(album11111);
    printf("Album Created\n");
    mainfile();
}
