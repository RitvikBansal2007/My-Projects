#include<stdio.h>
#include <string.h>
#include "mainfile.h"

typedef struct
{
    int number;
    char name[150];
    char artist[150];
    char album[150];
}song;

void deletesong()
{
    char x[150];
    char tempalbum[]="tempalbum";
    int m;
    song aaa;
    printf("Song ID to delete:");
    int id00;
    scanf("%d",&id00);
    FILE*songa=fopen("song.txt","r");
    FILE*songb=fopen("tempsong.txt","w");
    while(fscanf(songa,"%d %s %s %s",&(aaa.number),(aaa.name),(aaa.artist),(aaa.album))!=EOF)
    {
        if(aaa.number==id00)
        {
            strcpy(x,aaa.album);
            m=1;
        }
        if(aaa.number!=id00)
        fprintf(songb,"%d %s %s %s\n",aaa.number,aaa.name,aaa.artist,aaa.album);
    }
    fclose(songa);
    fclose(songb);
    remove("song.txt");
    rename("tempsong.txt","song.txt");
    if (!m)
    {
        printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
        char end[]="End";
        FILE*history1=fopen("history.txt","a");
        fprintf(history1,"%s\n",end);
        fclose(history1);
        return;
    }
    FILE*albuma=fopen(x,"r");
    FILE*albumb=fopen(tempalbum,"w");
    while(fscanf(albuma,"%d %s %s",&(aaa.number),(aaa.name),(aaa.artist))!=EOF)
    {
        if(aaa.number!=id00)
        fprintf(albumb,"%d %s %s %s\n",aaa.number,aaa.name,aaa.artist);
    }
    fclose(albuma);
    fclose(albumb);
    remove(x);
    rename(tempalbum,x);
    printf("Song Deleted\n");
    mainfile();
}
