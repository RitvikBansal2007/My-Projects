#include<stdio.h>
#include"mainfile.h"
#include<string.h>

typedef struct
{
    int number;
    char name[150];
    char artist[150];
    char album[150];
}song;

void deletealbum()
{
    song aa;
    printf("Album Name to delete:");
    char album100[150];
    scanf("%s",album100);
    remove(album100);
    FILE*album1000=fopen("album.txt","r");
    FILE*album10000=fopen("tempalbum.txt","w");
    FILE*song1000=fopen("song.txt","r");
    FILE*song10000=fopen("tempsong.txt","w");
    char alb[150];
    while(fscanf(album1000,"%s",alb)!=EOF)
    {
        if(strcmp(alb,album100)!=0)
        fprintf(album10000,"%s\n",alb);
    }
    fclose(album1000);
    fclose(album10000);
    remove("album.txt");
    rename("tempalbum.txt", "album.txt");
    while(fscanf(song1000,"%d %s %s %s",&(aa.number),(aa.name),(aa.artist),(aa.album))!=EOF)
    {
        if(strcmp(aa.album,album100)!=0)
        fprintf(song10000,"%d %s %s %s\n",aa.number,aa.name,aa.artist,aa.album);
    }
    fclose(song1000);
    fclose(song10000);
    remove("song.txt");
    rename("tempsong.txt","song.txt");
    printf("Album Deleted\n");
    mainfile();
}
