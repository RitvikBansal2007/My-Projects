#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mainfile.h"

typedef struct
{
    int number;
    char name[150];
    char artist[150];
    char album[150];
}song;

song c;

typedef struct node
{
    int number;
    char name[150];
    char artist[150];
    char album[150];
    struct node*prev;
    struct node*next;
}node;

node*head=NULL;
node*temp=NULL;

void insertsong(int a,char n[],char ar[],char al[])
{
    node*newnode=(node*)malloc(sizeof(node));
    newnode->number=a;
    strcpy(newnode->name,n);
    strcpy(newnode->artist,ar);
    strcpy(newnode->album,al);
    newnode->prev=NULL;
    newnode->next=NULL;
    if(head==NULL)
    {
        head=newnode;
        head->prev=head;
        head->next=head;
    }
    else
    {
        head->prev=newnode;
        node*temp=head;
        while(temp->next!=head) temp=temp->next;
        temp->next=newnode;
        newnode->next=head;
        newnode->prev=temp;
    }
}

void playalgo();

void removesongalgo()
{
    printf("Enter Song ID of the song to be removed:");
    int o;
    scanf("%d",&o);
    while(temp->number!=o)temp=temp->next;
    node*temp2=temp->next;
    node*temp3=temp2->next;
    temp->number=temp2->number;
    temp->next=temp2->next;
    strcpy(temp->artist,temp2->artist);
    strcpy(temp->name,temp2->name);
    strcpy(temp->album,temp2->album);
    temp3->prev=temp;
    printf("Song Removed from Queue\n");
    playalgo();
}

void playalgo()
{
    FILE*songtt=fopen("song.txt","r");
    printf("Playing %s from %s of %s\n",temp->name,temp->album,temp->artist);
    printf("Enter 'Next' to play next song\n");
    printf("Enter 'Previous' to play previous song\n");
    printf("Enter 'Stop' to stop playing\n");
    printf("Enter 'ADD'to add song to queue\n");
    printf("Enter 'Remove' to remove song from queue\n");
    printf("Enter 'Home' to go to home\n");
    char str8[40];
    scanf("%s",str8);
    FILE*history1=fopen("history.txt","a");
    fprintf(history1,"%s->",str8);
    fclose(history1);
    char next[]="Next";
    char previous[]="Previous";
    char stop[]="Stop";
    char add[]="ADD";
    char home[]="Home";
    char remove[]="Remove";
    if(strcmp(str8,next)==0)
    {
        temp=temp->next;
        fclose(songtt);
        playalgo();
    }
    else if(strcmp(str8,previous)==0)
    {
        temp=temp->prev;
        fclose(songtt);
        playalgo();
    }
    else if(strcmp(str8,home)==0)
    {
        fclose(songtt);
        mainfile();
    }
    else if(strcmp(str8,stop)==0)
    {
        fclose(songtt);
        printf("Song Stopped\n");
        printf("Enter 'Play' to play again\n");
        printf("Enter 'Home' to go to home\n");
        char str9[40];
        scanf("%s",str9);
        FILE*history1=fopen("history.txt","a");
        fprintf(history1,"%s->",str9);
        fclose(history1);
        char play[]="Play";
        char home[]="Home";
        if(strcmp(str9,play)==0) playalgo();
        else if (strcmp(str9,home)==0) mainfile();
        else 
        {
            printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
            char end[]="End";
            FILE*history1=fopen("history.txt","a");
            fprintf(history1,"%s\n",end);
            fclose(history1);
            return;
        }
    }
    else if(strcmp(str8,add)==0)
    {
        printf("Enter Song ID of song to be added:");
        int v;
        scanf("%d",&v);
        while(fscanf(songtt,"%d %s %s %s",&(c.number),(c.name),(c.artist),(c.album))!=EOF) if(c.number==v) break;
        insertsong(c.number,c.name,c.artist,c.album);
        printf("Song Added to Queue\n");
        fclose(songtt);
        playalgo();
    }
    else if(strcmp(str8,remove)==0)
    {
        fclose(songtt);
        removesongalgo();
    }
    else
    {
        printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
        char end[]="End";
        FILE*history1=fopen("history.txt","a");
        fprintf(history1,"%s\n",end);
        fclose(history1);
        return;
    }
}

void playsong()
{
    FILE*songtt=fopen("song.txt","r");
    printf("Enter Song ID:");
    int a;
    scanf("%d",&a);
    while(fscanf(songtt,"%d %s %s %s",&(c.number),(c.name),(c.artist),(c.album))!=EOF) if(c.number==a) break;
    insertsong(c.number,c.name,c.artist,c.album);
    fclose(songtt);
    temp=head;
    playalgo();
}
