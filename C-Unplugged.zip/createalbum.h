#ifndef CREATEALBUM_H
#define CREATEALBUM_H
void createalbum();
#endif