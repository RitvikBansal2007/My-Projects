#ifndef DELETESONG_H
#define DELETESONG_H
void deletesong();
#endif