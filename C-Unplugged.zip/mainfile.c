#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "addsong.h"
#include "deletealbum.h"
#include "deletesong.h"
#include "openalbum.h"
#include "createalbum.h"
#include "playsong.h"

FILE*song1;
FILE*album1;

typedef struct
{
    int number;
    char name[150];
    char artist[150];
    char album[150];
}song;

void mainfile()
{
    song a;
    char str[10];
    printf("\033[1;32m");
    printf("C-Unplugged\n\n");
    printf("What are You looking for\n");
    printf("Song?(Enter 'Song' to view all songs)\n");
    printf("Album?(Enter 'Album' to view all albums)\n");
    printf("History? naughtyyy...(Enter 'History' to view past records)\n");
    printf("Quit?(Enter 'Quit' to end program)\n");
    scanf("%s",str);
    FILE*history1=fopen("history.txt","a");
    fprintf(history1,"%s->",str);
    fclose(history1);
    char song[]="Song";
    char album[]="Album";
    char history[]="History";
    char quit[]="Quit";

    if(strcmp(str,song)==0)
    {
        printf("All Songs\n");
        song1=fopen("song.txt","r");
        while(fscanf(song1,"%d %s %s %s",&(a.number),(a.name),(a.artist),(a.album))!=EOF) 
        printf("ID=%d|Name=%s|Artist=%s|Album=%s\n",a.number,a.name,a.artist,a.album);
        printf("\n");
        printf("What You Want??\n");
        printf("ADD Song??(Enter 'ADD' to add new song)\n");
        printf("Play Song??(Enter 'Play' to play song)\n");
        printf("Delete Song??(Enter 'DeleteSong' to delete a song)\n");
        printf("Return to Home??(Enter 'Home' to go back to home)\n");
        char add12[]="ADD";
        char play[]="Play";
        char home[]="Home";
        char delete[]="DeleteSong";
        char str2[40];
        scanf("%s",str2);
        FILE*history1=fopen("history.txt","a");
        fprintf(history1,"%s->",str2);
        fclose(history1);
        if(strcmp(str2,add12)==0) addsong();
        else if(strcmp(str2,play)==0) playsong();
        else if(strcmp(str2,delete)==0) deletesong();
        else if(strcmp(str2,home)==0) mainfile();
        else
        {
            printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
            char end[]="End";
            FILE*history1=fopen("history.txt","a");
            fprintf(history1,"%s\n",end);
            fclose(history1);
            return;
        }
        fclose(song1);
    }

    else if(strcmp(str,album)==0)
    {
        char ar[150];
        printf("All Albums\n");
        album1=fopen("album.txt","r");
        while(fscanf(album1,"%s",(ar))==1) printf("%s\n",ar);
        printf("\n");
        printf("What You Want??\n");
        printf("Open Album??(Enter 'Open' to open an album)\n");
        printf("Delete Album??(Enter 'DeleteAlbum' to delete a song)\n");
        printf("Return to Home??(Enter 'Home' to go back to home)\n");
        printf("Create Album??(Enter 'Create' to make new album)\n");
        char open[]="Open";
        char home[]="Home";
        char delete[]="DeleteAlbum";
        char create[]="Create";
        char str3[40];
        scanf("%s",str3);
        FILE*history1=fopen("history.txt","a");
        fprintf(history1,"%s->",str3);
        fclose(history1);
        if(strcmp(str3,open)==0) openalbum();
        else if(strcmp(str3,delete)==0) deletealbum();
        else if (strcmp(str3,home)==0) mainfile();
        else if (strcmp(str3,create)==0) createalbum();
        else
        {
            printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
            char end[]="End";
            FILE*history1=fopen("history.txt","a");
            fprintf(history1,"%s\n",end);
            fclose(history1);
            return;
        }
        fclose(album1);

    }

    else if(strcmp(str,history)==0)
    {
        char line[1000];
        printf("Past Records\n");
        FILE*history1;
        history1=fopen("history.txt","r");
        while (fscanf(history1,"%s",line)!= EOF) printf("%s\n", line);
        fclose(history1);
        printf("What You Want??\n");
        printf("Return to Home??(Enter 'Home' to go back to home)\n");
        char home[]="Home";
        char str6[40];
        scanf("%s",str6);
        history1=fopen("history.txt","a");
        fprintf(history1,"%s->",str6);
        fclose(history1);
        if (strcmp(str6,home)==0) mainfile();
        else
        {
            printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
            char end[]="End";
            FILE*history1=fopen("history.txt","a");
            fprintf(history1,"%s\n",end);
            fclose(history1);
            return;
        }
    }

    else if(strcmp(str,quit)==0) 
    {
        char end[]="End";
        FILE*history1=fopen("history.txt","a");
        fprintf(history1,"%s\n",end);
        fclose(history1);
        return;
    }
    else
    {
        printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
        char end[]="End";
        FILE*history1=fopen("history.txt","a");
        fprintf(history1,"%s\n",end);
        fclose(history1);
        return;
    }
}
