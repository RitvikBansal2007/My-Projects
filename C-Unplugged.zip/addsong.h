#ifndef ADDSONG_H
#define ADDSONG_H
void addsong();
#endif