#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "addsong.h"
#include "playsong.h"
#include "deletesong.h"
#include "mainfile.h"

typedef struct
{
    int number;
    char name[150];
    char artist[150];
    char album[150];
}song;

void openalbum()
{
    FILE*album00;
    char album234567[150];
    song arr;
    printf("\033[1;31mDisclaimer:Don't Put Space in between Name (Ritvik Bansal to be written as RitvikBansal)\033[1;32m\n");
    printf("Album Name to Open:");
    scanf("%s",album234567);
    album00=fopen(album234567,"r");
    while(fscanf(album00,"%d %s %s",&(arr.number),(arr.name),(arr.artist))!=EOF)
    printf("ID=%d|Name=%s|Artist=%s\n",arr.number,arr.name,arr.artist);
    printf("\n");
    printf("What You Want??\n");
    printf("ADD Song??(Enter 'ADD' to add new song)\n");
    printf("Play Song??(Enter 'Play' to play song)\n");
    printf("Delete Song??(Enter 'Delete' to delete a song)\n");
    printf("Return to Home??(Enter 'Home' to go back to home)\n");
    char add12[]="ADD";
    char play[]="Play";
    char home[]="Home";
    char delete[]="Delete";
    char str5[40];
    scanf("%s",str5);
    FILE*history1=fopen("history.txt","a");
    fprintf(history1,"%s->",str5);
    fclose(history1);
    if(strcmp(str5,add12)==0) addsong();
    else if(strcmp(str5,play)==0) playsong();
    else if(strcmp(str5,delete)==0) deletesong();
    else if(strcmp(str5,home)==0) mainfile();
    else 
        {
            printf("\033[1;31mInvalid Command Program Terminates\033[1;32m\n");
            char end[]="End";
            FILE*history1=fopen("history.txt","a");
            fprintf(history1,"%s\n",end);
            fclose(history1);
            return;
        }
    fclose(album00);
}
